import 'dart:math' as math;
import 'dart:typed_data';

/// शोर हटाने के विकल्प।
class CleanOptions {
  const CleanOptions({
    this.hum = false,
    this.rumble = false,
    this.hiss = false,
    this.normalize = false,
  });

  /// बिजली की भिनभिनाहट (50 Hz और उसके गुणज)।
  final bool hum;

  /// हवा, मेज़ की थरथराहट और नीची गड़गड़ाहट।
  final bool rumble;

  /// हिस्स और पंखे जैसा लगातार शोर।
  final bool hiss;

  /// आवाज़ को बराबर और तेज़ करना।
  final bool normalize;

  bool get any => hum || rumble || hiss || normalize;
}

/// दूसरे दर्जे का फ़िल्टर (RBJ बाइक्वाड)।
class _Biquad {
  _Biquad(this.b0, this.b1, this.b2, this.a1, this.a2);

  factory _Biquad.highPass(double fs, double f0, double q) {
    final w = 2 * math.pi * f0 / fs;
    final alpha = math.sin(w) / (2 * q);
    final c = math.cos(w);
    final a0 = 1 + alpha;
    return _Biquad(
      (1 + c) / 2 / a0,
      -(1 + c) / a0,
      (1 + c) / 2 / a0,
      -2 * c / a0,
      (1 - alpha) / a0,
    );
  }

  factory _Biquad.notch(double fs, double f0, double q) {
    final w = 2 * math.pi * f0 / fs;
    final alpha = math.sin(w) / (2 * q);
    final c = math.cos(w);
    final a0 = 1 + alpha;
    return _Biquad(1 / a0, -2 * c / a0, 1 / a0, -2 * c / a0, (1 - alpha) / a0);
  }

  final double b0;
  final double b1;
  final double b2;
  final double a1;
  final double a2;

  Float64List run(Float64List x) {
    final y = Float64List(x.length);
    var x1 = 0.0;
    var x2 = 0.0;
    var y1 = 0.0;
    var y2 = 0.0;
    for (var i = 0; i < x.length; i++) {
      final v = b0 * x[i] + b1 * x1 + b2 * x2 - a1 * y1 - a2 * y2;
      y[i] = v;
      x2 = x1;
      x1 = x[i];
      y2 = y1;
      y1 = v;
    }
    return y;
  }
}

/// क्रम 2 की ताकत पर FFT (इन-प्लेस, [re] और [im] की लंबाई 2 की घात)।
void _fft(Float64List re, Float64List im, {bool inverse = false}) {
  final n = re.length;
  var j = 0;
  for (var i = 1; i < n; i++) {
    var bit = n >> 1;
    for (; j & bit != 0; bit >>= 1) {
      j ^= bit;
    }
    j ^= bit;
    if (i < j) {
      final tr = re[i];
      re[i] = re[j];
      re[j] = tr;
      final ti = im[i];
      im[i] = im[j];
      im[j] = ti;
    }
  }
  for (var len = 2; len <= n; len <<= 1) {
    final ang = 2 * math.pi / len * (inverse ? 1 : -1);
    final wr = math.cos(ang);
    final wi = math.sin(ang);
    for (var i = 0; i < n; i += len) {
      var cr = 1.0;
      var ci = 0.0;
      for (var k = 0; k < len ~/ 2; k++) {
        final ur = re[i + k];
        final ui = im[i + k];
        final vr = re[i + k + len ~/ 2] * cr - im[i + k + len ~/ 2] * ci;
        final vi = re[i + k + len ~/ 2] * ci + im[i + k + len ~/ 2] * cr;
        re[i + k] = ur + vr;
        im[i + k] = ui + vi;
        re[i + k + len ~/ 2] = ur - vr;
        im[i + k + len ~/ 2] = ui - vi;
        final ncr = cr * wr - ci * wi;
        ci = cr * wi + ci * wr;
        cr = ncr;
      }
    }
  }
  if (inverse) {
    for (var i = 0; i < n; i++) {
      re[i] /= n;
      im[i] /= n;
    }
  }
}

/// लगातार शोर (हिस्स/पंखा) घटाता है: सबसे शांत हिस्सों से शोर का नमूना लेकर
/// स्पेक्ट्रल सबट्रैक्शन करता है।
Float64List spectralDenoise(
  Float64List x, {
  double strength = 1.6,
  double floor = 0.08,
  Float64List? noiseSample,
}) {
  const n = 1024;
  const hop = 256;
  const bins = n ~/ 2 + 1;
  if (x.length < n * 4) return x;
  final win = Float64List(n);
  for (var i = 0; i < n; i++) {
    win[i] = 0.5 - 0.5 * math.cos(2 * math.pi * i / n);
  }
  final frames = (x.length - n) ~/ hop + 1;
  final energy = Float64List(frames);
  for (var f = 0; f < frames; f++) {
    var e = 0.0;
    final o = f * hop;
    for (var i = 0; i < n; i++) {
      e += x[o + i] * x[o + i];
    }
    energy[f] = e;
  }
  final sorted = energy.toList()..sort();
  final take = math.max(4, (frames * 0.12).round());
  final thresh = sorted[math.min(take, frames) - 1];

  // शोर का औसत स्पेक्ट्रम: या तो दिए नमूने से, या सबसे शांत फ्रेमों से
  final noise = Float64List(bins);
  var cnt = 0;
  final re = Float64List(n);
  final im = Float64List(n);
  final src = (noiseSample != null && noiseSample.length >= n * 2) ? noiseSample : x;
  final useSample = identical(src, noiseSample);
  final srcFrames = (src.length - n) ~/ hop + 1;
  for (var f = 0; f < srcFrames; f++) {
    if (!useSample && energy[f] > thresh) continue;
    final o = f * hop;
    for (var i = 0; i < n; i++) {
      re[i] = src[o + i] * win[i];
      im[i] = 0;
    }
    _fft(re, im);
    for (var k = 0; k < bins; k++) {
      noise[k] += math.sqrt(re[k] * re[k] + im[k] * im[k]);
    }
    cnt++;
  }
  if (cnt == 0) return x;
  for (var k = 0; k < bins; k++) {
    noise[k] /= cnt;
  }

  final out = Float64List(x.length);
  final norm = Float64List(x.length);
  final prevGain = Float64List(bins)..fillRange(0, bins, 1);
  for (var f = 0; f < frames; f++) {
    final o = f * hop;
    for (var i = 0; i < n; i++) {
      re[i] = x[o + i] * win[i];
      im[i] = 0;
    }
    _fft(re, im);
    for (var k = 0; k < bins; k++) {
      final mag = math.sqrt(re[k] * re[k] + im[k] * im[k]);
      var gain = mag <= 1e-12 ? 0.0 : (mag - strength * noise[k]) / mag;
      gain = gain.clamp(floor, 1.0);
      // समय में चिकना करना, ताकि "टिंकलिंग" जैसी आवाज़ न आए
      gain = 0.6 * prevGain[k] + 0.4 * gain;
      prevGain[k] = gain;
      re[k] *= gain;
      im[k] *= gain;
      if (k > 0 && k < n ~/ 2) {
        re[n - k] = re[k];
        im[n - k] = -im[k];
      }
    }
    _fft(re, im, inverse: true);
    for (var i = 0; i < n; i++) {
      out[o + i] += re[i] * win[i];
      norm[o + i] += win[i] * win[i];
    }
  }
  for (var i = 0; i < x.length; i++) {
    out[i] = norm[i] > 1e-6 ? out[i] / norm[i] : x[i];
  }
  return out;
}

Float64List _normalize(Float64List x) {
  var peak = 0.0;
  for (final v in x) {
    final a = v.abs();
    if (a > peak) peak = a;
  }
  if (peak < 1e-4) return x;
  final g = 0.89 / peak; // लगभग -1 dB
  return Float64List.fromList([for (final v in x) v * g]);
}

/// चुने गए विकल्पों के हिसाब से सफ़ाई करता है।
Float64List cleanAudio(
  Float64List input,
  int sampleRate,
  CleanOptions o, {
  double hissStrength = 1.6,
  double hissFloor = 0.08,
  Float64List? noiseSample,
}) {
  var x = input;
  final fs = sampleRate.toDouble();
  if (o.rumble) x = _Biquad.highPass(fs, 100, 0.707).run(x);
  if (o.hum) {
    for (var h = 1; h <= 4; h++) {
      final f = 50.0 * h;
      if (f < fs / 2 - 100) x = _Biquad.notch(fs, f, 35).run(x);
    }
  }
  if (o.hiss) {
    x = spectralDenoise(
      x,
      strength: hissStrength,
      floor: hissFloor,
      noiseSample: noiseSample,
    );
  }
  if (o.normalize) x = _normalize(x);
  return x;
}
