import 'dart:io';
import 'dart:isolate';

import 'package:archive/archive_io.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';

import 'drive_link.dart';

/// फ़ोन में मिला भजन का फ़ोल्डर या ज़िप।
class BhajanSource {
  const BhajanSource(this.path, {required this.isZip});

  final String path;
  final bool isZip;

  String get name => path.split('/').last;
}

const _scanDirs = [
  '/storage/emulated/0/Download',
  '/storage/emulated/0/Downloads',
  '/storage/emulated/0/Documents',
  '/storage/emulated/0',
];

bool _looksLikeBhajan(String name) {
  final n = name.toLowerCase();
  return n.contains('bhajan') || n.contains('भजन');
}

/// डाउनलोड आदि में "Bhajan" नाम वाले फ़ोल्डर और ज़िप ढूँढता है।
Future<List<BhajanSource>> findBhajanSources(String root) async {
  final out = <BhajanSource>[];
  final seen = <String>{};
  for (final d in _scanDirs) {
    final dir = Directory(d);
    try {
      if (!await dir.exists()) continue;
      await for (final e in dir.list(followLinks: false)) {
        final name = e.path.split('/').last;
        if (name.startsWith('.') || e.path == root || !seen.add(e.path)) continue;
        if (!_looksLikeBhajan(name)) continue;
        if (e is Directory) {
          out.add(BhajanSource(e.path, isZip: false));
        } else if (e is File && name.toLowerCase().endsWith('.zip')) {
          out.add(BhajanSource(e.path, isZip: true));
        }
      }
    } on FileSystemException {
      continue;
    }
  }
  return out;
}

bool _skip(String name) =>
    name.startsWith('.') || name.startsWith('._') || name == '__MACOSX';

/// [from] की सारी चीज़ें [to] में मिलाता है (जो पहले से है उसे छोड़ देता है)।
Future<int> _mergeInto(Directory from, Directory to, {required bool move}) async {
  var n = 0;
  await to.create(recursive: true);
  await for (final e in from.list(followLinks: false)) {
    final name = e.path.split('/').last;
    if (_skip(name)) continue;
    final dst = '${to.path}/$name';
    if (e is Directory) {
      n += await _mergeInto(e, Directory(dst), move: move);
    } else if (e is File) {
      if (await File(dst).exists()) continue;
      if (move) {
        try {
          await e.rename(dst);
        } on FileSystemException {
          await e.copy(dst);
          await e.delete();
        }
      } else {
        await e.copy(dst);
      }
      n++;
    }
  }
  return n;
}

/// अकेले फ़ोल्डर के अंदर फ़ोल्डर हो (जैसे Bhajan/Bhajan/...) तो उसके अंदर उतरता है।
Future<Directory> _contentRoot(Directory d) async {
  var cur = d;
  for (var i = 0; i < 3; i++) {
    final kids = <FileSystemEntity>[];
    await for (final e in cur.list(followLinks: false)) {
      if (!_skip(e.path.split('/').last)) kids.add(e);
    }
    if (kids.length == 1 && kids.first is Directory) {
      cur = kids.first as Directory;
    } else {
      break;
    }
  }
  return cur;
}

/// ज़िप/फ़ोल्डर के भजन [root] में जोड़ता है। लौटाता है: कितनी फ़ाइलें जुड़ीं।
Future<int> importBhajan(BhajanSource src, String root) {
  return Isolate.run(() async {
    final rootDir = Directory(root);
    await rootDir.create(recursive: true);
    if (!src.isZip) {
      final c = await _contentRoot(Directory(src.path));
      return _mergeInto(c, rootDir, move: false);
    }
    final tmp = Directory('$root/.import_tmp');
    if (await tmp.exists()) await tmp.delete(recursive: true);
    await tmp.create(recursive: true);
    try {
      await extractFileToDisk(src.path, tmp.path);
      final c = await _contentRoot(tmp);
      return await _mergeInto(c, rootDir, move: true);
    } finally {
      if (await tmp.exists()) await tmp.delete(recursive: true);
    }
  });
}

/// "भजन जोड़ें" का पूरा काम: विकल्प दिखाओ, चुने को जोड़ो। लौटाता है: जुड़ी फ़ाइलें (रद्द पर null)।
Future<int?> importFlow(BuildContext context, String root) async {
  final found = await findBhajanSources(root);
  if (!context.mounted) return null;
  final choice = await showDialog<Object>(
    context: context,
    builder: (c) => SimpleDialog(
      title: const Text('भजन ऐप में जोड़ें'),
      children: [
        if (found.isEmpty)
          const Padding(
            padding: EdgeInsets.fromLTRB(24, 0, 24, 12),
            child: Text('फ़ोन के Downloads में "Bhajan" नाम का फ़ोल्डर या ज़िप नहीं मिला। नीचे से खुद चुन लीजिए।'),
          ),
        for (final s in found)
          SimpleDialogOption(
            onPressed: () => Navigator.pop(c, s),
            child: Text(
              '${s.isZip ? '📦' : '📁'} ${s.name}',
              style: const TextStyle(fontSize: 18),
            ),
          ),
        SimpleDialogOption(
          onPressed: () => Navigator.pop(c, 'link'),
          child: const Text('🔗 लिंक से डाउनलोड करें (Google Drive)', style: TextStyle(fontSize: 18)),
        ),
        SimpleDialogOption(
          onPressed: () => Navigator.pop(c, 'zip'),
          child: const Text('📦 ज़िप फ़ाइल खुद चुनें', style: TextStyle(fontSize: 18)),
        ),
        SimpleDialogOption(
          onPressed: () => Navigator.pop(c, 'dir'),
          child: const Text('📁 फ़ोल्डर खुद चुनें', style: TextStyle(fontSize: 18)),
        ),
      ],
    ),
  );
  if (choice == null || !context.mounted) return null;
  BhajanSource? src;
  if (choice is BhajanSource) {
    src = choice;
  } else if (choice == 'link') {
    return _linkFlow(context, root);
  } else if (choice == 'zip') {
    final r = await FilePicker.pickFiles(
      type: FileType.custom,
      allowedExtensions: const ['zip'],
    );
    final p = r.isEmpty ? null : r.first.path;
    if (p != null) src = BhajanSource(p, isZip: true);
  } else {
    final p = await FilePicker.getDirectoryPath();
    if (p != null) src = BhajanSource(p, isZip: false);
  }
  if (src == null || !context.mounted) return null;

  showDialog<void>(
    context: context,
    barrierDismissible: false,
    builder: (_) => const PopScope(
      canPop: false,
      child: AlertDialog(
        title: Text('भजन जोड़े जा रहे हैं…'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            LinearProgressIndicator(),
            SizedBox(height: 12),
            Text('बड़ी फ़ाइल है, कुछ मिनट लग सकते हैं। ऐप बंद न करें।'),
          ],
        ),
      ),
    ),
  );
  int? n;
  try {
    n = await importBhajan(src, root);
  } on Object {
    n = -1;
  }
  if (context.mounted) Navigator.of(context, rootNavigator: true).pop();
  return n;
}

/// लिंक डालो → ज़िप उतारो (प्रगति के साथ) → ऐप में जोड़ो।
Future<int?> _linkFlow(BuildContext context, String root) async {
  final ctrl = TextEditingController(text: await loadSavedLink());
  if (!context.mounted) return null;
  final link = await showDialog<String>(
    context: context,
    builder: (c) => AlertDialog(
      title: const Text('भजन की लिंक'),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          TextField(
            controller: ctrl,
            maxLines: 3,
            decoration: const InputDecoration(
              hintText: 'Google Drive की लिंक यहाँ चिपकाएँ',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 8),
          const Text(
            'लिंक एक बार चिपकाइए, ऐप याद रखेगा। बाद में नए भजन आएँ तो यही बटन दबाइए — सिर्फ़ नए जुड़ेंगे।',
            style: TextStyle(fontSize: 13),
          ),
        ],
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(c), child: const Text('रद्द')),
        FilledButton(
          onPressed: () => Navigator.pop(c, ctrl.text.trim()),
          child: const Text('डाउनलोड'),
        ),
      ],
    ),
  );
  if (link == null || link.isEmpty || !context.mounted) return null;
  await saveLink(link);
  if (!context.mounted) return null;

  var cancelled = false;
  final progress = ValueNotifier<(int, int)>((0, 0));
  showDialog<void>(
    context: context,
    barrierDismissible: false,
    builder: (c) => PopScope(
      canPop: false,
      child: AlertDialog(
        title: const Text('डाउनलोड हो रहा है…'),
        content: ValueListenableBuilder<(int, int)>(
          valueListenable: progress,
          builder: (ctx, v, child) {
            final mb = (v.$1 / 1048576).toStringAsFixed(0);
            final totalMb = v.$2 > 0 ? ' / ${(v.$2 / 1048576).toStringAsFixed(0)}' : '';
            return Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                LinearProgressIndicator(value: v.$2 > 0 ? v.$1 / v.$2 : null),
                const SizedBox(height: 12),
                Text('$mb$totalMb MB'),
                const SizedBox(height: 8),
                const Text('वाई-फ़ाई पर रखें। ऐप बंद न करें।', style: TextStyle(fontSize: 13)),
              ],
            );
          },
        ),
        actions: [
          TextButton(onPressed: () => cancelled = true, child: const Text('रोकें')),
        ],
      ),
    ),
  );

  final zip = '$root/.download/bhajan.zip';
  int? n;
  String? err;
  try {
    await downloadToFile(
      link,
      zip,
      onProgress: (g, t) => progress.value = (g, t),
      isCancelled: () => cancelled,
    );
    n = await importBhajan(BhajanSource(zip, isZip: true), root);
  } on DownloadCancelled {
    n = null;
  } on Object catch (e) {
    err = e.toString();
    n = -1;
  }
  try {
    final d = Directory('$root/.download');
    if (await d.exists()) await d.delete(recursive: true);
  } on Object {
    // ठीक है
  }
  if (context.mounted) Navigator.of(context, rootNavigator: true).pop();
  if (err != null && context.mounted) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(err)));
  }
  return n;
}
