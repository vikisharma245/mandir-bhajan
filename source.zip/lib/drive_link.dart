import 'dart:async';
import 'dart:io';

import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

const _linkKey = 'bhajan_zip_link';

Future<String> loadSavedLink() async {
  final p = await SharedPreferences.getInstance();
  return p.getString(_linkKey) ?? '';
}

Future<void> saveLink(String link) async {
  final p = await SharedPreferences.getInstance();
  await p.setString(_linkKey, link.trim());
}

/// Google Drive की अलग-अलग तरह की लिंक से फ़ाइल की पहचान निकालता है।
String? driveFileId(String link) {
  final u = Uri.tryParse(link.trim());
  if (u == null) return null;
  final byPath = RegExp(r'/d/([A-Za-z0-9_-]{10,})').firstMatch(u.path);
  if (byPath != null) return byPath.group(1);
  final id = u.queryParameters['id'];
  if (id != null && id.length >= 10) return id;
  return null;
}

/// लिंक से सीधा डाउनलोड का पता। Drive हो तो बड़ी फ़ाइल की "वायरस जाँच" चेतावनी पार करता है।
Uri downloadUri(String link) {
  final id = driveFileId(link);
  if (id != null) {
    return Uri.parse(
      'https://drive.usercontent.google.com/download?id=$id&export=download&confirm=t',
    );
  }
  return Uri.parse(link.trim());
}

class DownloadCancelled implements Exception {}

/// [link] से फ़ाइल [destPath] में उतारता है। [onProgress] को (मिले, कुल) बाइट मिलते हैं।
/// [isCancelled] सच हो जाए तो रुक जाता है। कुल अज्ञात हो तो 0।
Future<void> downloadToFile(
  String link,
  String destPath, {
  required void Function(int got, int total) onProgress,
  required bool Function() isCancelled,
}) async {
  final client = http.Client();
  try {
    final req = http.Request('GET', downloadUri(link));
    final resp = await client.send(req);
    if (resp.statusCode != 200) {
      throw HttpException('लिंक नहीं खुली (कोड ${resp.statusCode})');
    }
    final type = resp.headers['content-type'] ?? '';
    if (type.contains('text/html')) {
      throw const HttpException(
        'यह फ़ाइल नहीं, वेब पेज है। Drive में शेयरिंग "लिंक वाला कोई भी" रखें।',
      );
    }
    final file = File(destPath);
    await file.parent.create(recursive: true);
    final sink = file.openWrite();
    var got = 0;
    final total = resp.contentLength ?? 0;
    try {
      await for (final chunk in resp.stream) {
        if (isCancelled()) throw DownloadCancelled();
        sink.add(chunk);
        got += chunk.length;
        onProgress(got, total);
      }
    } finally {
      await sink.close();
    }
  } finally {
    client.close();
  }
}
