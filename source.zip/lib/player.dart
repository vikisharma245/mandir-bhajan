import 'package:flutter/foundation.dart';
import 'package:just_audio/just_audio.dart';

import 'library.dart';

/// पूरे ऐप का एक प्लेयर: सूची चलाता है, अगला/पिछला/मिलाकर चलाना संभालता है।
class PlayerController extends ChangeNotifier {
  PlayerController() {
    _player.processingStateStream.listen((state) {
      if (state == ProcessingState.completed) {
        next();
      }
    });
    _player.playerStateStream.listen((_) => notifyListeners());
  }

  final AudioPlayer _player = AudioPlayer();
  List<Track> _queue = const [];
  int _index = 0;

  AudioPlayer get audio => _player;
  List<Track> get queue => _queue;
  int get index => _index;
  Track? get current => _queue.isEmpty ? null : _queue[_index];
  bool get isPlaying => _player.playing;

  Future<void> playQueue(List<Track> queue, int start) async {
    if (queue.isEmpty) return;
    _queue = List.of(queue);
    await _playAt(start);
  }

  Future<void> _playAt(int i) async {
    if (_queue.isEmpty) return;
    _index = (i + _queue.length) % _queue.length;
    notifyListeners();
    try {
      await _player.setFilePath(_queue[_index].path);
      await _player.play();
    } on Object catch (e) {
      debugPrint('play error: $e');
    }
  }

  Future<void> next() => _playAt(_index + 1);

  Future<void> previous() => _playAt(_index - 1);

  Future<void> toggle() async {
    if (_queue.isEmpty) return;
    if (_player.playing) {
      await _player.pause();
    } else {
      await _player.play();
    }
    notifyListeners();
  }

  Future<void> shuffleAndPlay() async {
    if (_queue.isEmpty) return;
    _queue = List.of(_queue)..shuffle();
    await _playAt(0);
  }

  Future<void> seek(Duration d) => _player.seek(d);

  @override
  void dispose() {
    _player.dispose();
    super.dispose();
  }
}
