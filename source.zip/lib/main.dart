import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:speech_to_text/speech_to_text.dart';
import 'package:url_launcher/url_launcher.dart';

import 'catalog.dart';
import 'clean_ui.dart';
import 'editor.dart';
import 'import_bhajan.dart';
import 'library.dart';
import 'player.dart';
import 'recorder.dart';
import 'services.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const MandirApp());
}

const _saffron = Color(0xFFE8590C);
const _cream = Color(0xFFFFF7EC);
const _headerGradient = LinearGradient(
  colors: [Color(0xFFE8590C), Color(0xFFF59F00)],
);

const _godIcons = <String, String>{
  'शिव जी': '🔱',
  'गणेश जी': '🐘',
  'माँ पार्वती': '🌸',
  'हनुमान जी': '🚩',
  'राम जी': '🏹',
  'कृष्ण जी': '🪈',
  'माँ दुर्गा': '🦁',
  'माँ लक्ष्मी': '🪷',
  'आरती': '🪔',
  'लेडीज़ भजन': '🎙️',
  'त्योहार के भजन': '🎉',
  'श्रीमद्भगवद्गीता': '📿',
};

class MandirApp extends StatelessWidget {
  const MandirApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'मंदिर भजन',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: _saffron),
        scaffoldBackgroundColor: _cream,
        useMaterial3: true,
      ),
      home: const HomePage(),
    );
  }
}

Future<void> openUrl(String url) async {
  await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final player = PlayerController();
  String root = defaultRoot;
  List<Track> all = const [];
  bool loading = true;
  bool hasAccess = false;
  String? busyMessage;

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    root = await loadRoot();
    hasAccess = await ensureStorageAccess();
    await _reload();
    if (!mounted) return;
    if (hasAccess && all.isEmpty) {
      final found = await findBhajanSources(root);
      if (found.isNotEmpty && mounted) await _importBhajan();
    }
    final u = await checkForUpdate();
    if (u != null && mounted) _showUpdate(u);
  }

  Future<void> _reload() async {
    setState(() => loading = true);
    final found = hasAccess ? await scanLibrary(root) : <Track>[];
    if (!mounted) return;
    setState(() {
      all = found;
      loading = false;
    });
  }

  void _showUpdate(UpdateInfo u) {
    showDialog<void>(
      context: context,
      builder: (c) => AlertDialog(
        title: Text('नया वर्शन ${u.version} आया है'),
        content: Text(u.notes.isEmpty ? 'अपडेट करने के लिए नीचे दबाएँ।' : u.notes),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c), child: const Text('बाद में')),
          FilledButton(
            onPressed: () {
              Navigator.pop(c);
              openUrl(u.url);
            },
            child: const Text('अपडेट करें'),
          ),
        ],
      ),
    );
  }

  Future<void> _importBhajan() async {
    final n = await importFlow(context, root);
    if (n == null || !mounted) return;
    if (n < 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('भजन नहीं जुड़ पाए। जगह या अनुमति जाँचिए।')),
      );
      return;
    }
    await _reload();
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('$n नई फ़ाइलें जुड़ गईं।')),
    );
  }

  Future<void> _pickFolder() async {
    final p = await FilePicker.getDirectoryPath();
    if (p == null) return;
    await saveRoot(p);
    root = p;
    await _reload();
  }

  Future<void> _copyAllToUsb() async {
    if (all.isEmpty) return;
    final dest = await FilePicker.getDirectoryPath(
      dialogTitle: 'पेन ड्राइव चुनें',
    );
    if (dest == null || !mounted) return;
    var ok = 0;
    for (var i = 0; i < all.length; i++) {
      setState(() => busyMessage = 'कॉपी हो रहा है… ${i + 1} / ${all.length}');
      if (await copyTrackKeepingFolders(all[i], dest)) ok++;
    }
    if (!mounted) return;
    setState(() => busyMessage = null);
    _snack('$ok फ़ाइल कॉपी हो गईं। अब पेन ड्राइव सुरक्षित निकाल सकते हैं।');
  }

  void _snack(String m) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));
  }

  @override
  void dispose() {
    player.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: _saffron,
        foregroundColor: Colors.white,
        flexibleSpace: const DecoratedBox(decoration: BoxDecoration(gradient: _headerGradient)),
        title: const Text('🕉️ मंदिर भजन', style: TextStyle(fontWeight: FontWeight.w800)),
        actions: [
          IconButton(
            tooltip: 'भजन फोल्डर बदलें',
            icon: const Icon(Icons.folder_open),
            onPressed: _pickFolder,
          ),
          PopupMenuButton<String>(
            onSelected: (v) async {
              if (v == 'usb') await _copyAllToUsb();
              if (v == 'free') await openUrl(freeSiteUrl);
              if (v == 'upd') {
                final u = await checkForUpdate();
                if (!mounted) return;
                if (u == null) {
                  _snack('आपके पास नया वर्शन है।');
                } else {
                  _showUpdate(u);
                }
              }
              if (v == 'rescan') await _reload();
            },
            itemBuilder: (c) => const [
              PopupMenuItem(value: 'usb', child: Text('💾 सब कुछ पेन ड्राइव में')),
              PopupMenuItem(value: 'free', child: Text('🎁 मुफ़्त भजन साइट')),
              PopupMenuItem(value: 'rescan', child: Text('🔄 सूची फिर से देखें')),
              PopupMenuItem(value: 'upd', child: Text('⬆ अपडेट जाँचें')),
            ],
          ),
        ],
      ),
      body: _body(),
    );
  }

  Widget _body() {
    if (loading) return const Center(child: CircularProgressIndicator());
    if (!hasAccess) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text(
                'भजन पढ़ने के लिए फ़ोन की फ़ाइलों की अनुमति चाहिए।',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 20),
              ),
              const SizedBox(height: 16),
              FilledButton(
                onPressed: () async {
                  hasAccess = await ensureStorageAccess();
                  await _reload();
                },
                child: const Text('अनुमति दें'),
              ),
            ],
          ),
        ),
      );
    }
    return Column(
      children: [
        Container(
          width: double.infinity,
          margin: const EdgeInsets.all(12),
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: const Color(0xFFFFF1DE),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Text(
            busyMessage ??
                (all.isEmpty
                    ? 'अभी कोई भजन नहीं है। नीचे हरा बटन "भजन जोड़ें" दबाइए और Downloads में रखी Bhajan की ज़िप चुन लीजिए।'
                    : '✅ फोल्डर: $root — कुल ${all.length} ऑडियो'),
            style: const TextStyle(fontSize: 16, height: 1.5),
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 0, 12, 8),
          child: SizedBox(
            width: double.infinity,
            child: FilledButton.icon(
              style: FilledButton.styleFrom(
                backgroundColor: Colors.green.shade700,
                padding: const EdgeInsets.symmetric(vertical: 14),
              ),
              onPressed: _importBhajan,
              icon: const Icon(Icons.download_for_offline, size: 28),
              label: const Text(
                'भजन जोड़ें (ज़िप / फ़ोल्डर से)',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700),
              ),
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 0, 12, 8),
          child: SizedBox(
            width: double.infinity,
            child: FilledButton.icon(
              style: FilledButton.styleFrom(
                backgroundColor: const Color(0xFF9A3412),
                padding: const EdgeInsets.symmetric(vertical: 14),
              ),
              onPressed: () => Navigator.of(context).push(
                MaterialPageRoute<void>(
                  builder: (_) => SearchPage(all: all, player: player),
                ),
              ),
              icon: const Icon(Icons.record_voice_over, size: 28),
              label: const Text(
                'बोलकर भजन खोजें',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700),
              ),
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12),
          child: SizedBox(
            width: double.infinity,
            child: FilledButton.icon(
              style: FilledButton.styleFrom(
                backgroundColor: Colors.red.shade700,
                padding: const EdgeInsets.symmetric(vertical: 14),
              ),
              onPressed: () => Navigator.of(context).push(
                MaterialPageRoute<void>(
                  builder: (_) => RecorderPage(root: root, onSaved: _reload),
                ),
              ),
              icon: const Icon(Icons.mic, size: 28),
              label: const Text(
                'लाइव भजन रिकॉर्ड करें',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700),
              ),
            ),
          ),
        ),
        Expanded(
          child: GridView.count(
            padding: const EdgeInsets.all(12),
            crossAxisCount: 2,
            mainAxisSpacing: 12,
            crossAxisSpacing: 12,
            childAspectRatio: 1.1,
            children: [
              for (final g in gods) _tile(g),
            ],
          ),
        ),
      ],
    );
  }

  Widget _tile(God g) {
    final n = tracksOf(all, g).length;
    final has = n > 0;
    return Material(
      color: Colors.transparent,
      borderRadius: BorderRadius.circular(20),
      elevation: has ? 3 : 0,
      child: InkWell(
        borderRadius: BorderRadius.circular(20),
        onTap: () => Navigator.of(context).push(
          MaterialPageRoute<void>(
            builder: (_) => GodPage(
              god: g,
              all: all,
              player: player,
              reload: () async {
                await _reload();
                return all;
              },
            ),
          ),
        ),
        child: Ink(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20),
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: has
                  ? const [Color(0xFFFFFFFF), Color(0xFFFFE3C2)]
                  : const [Color(0xFFFFFFFF), Color(0xFFF6EEE4)],
            ),
            border: Border.all(
              color: has ? _saffron : const Color(0xFFF3D9BD),
              width: has ? 2.5 : 1.5,
            ),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(_godIcons[g.name] ?? '🕉️', style: const TextStyle(fontSize: 34)),
              const SizedBox(height: 4),
              Text(
                g.name,
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800),
              ),
              const SizedBox(height: 2),
              Text(
                has ? '$n ऑडियो' : 'अभी कुछ नहीं',
                style: TextStyle(
                  fontSize: 13,
                  color: has ? const Color(0xFF9A3412) : Colors.black45,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class GodPage extends StatefulWidget {
  const GodPage({
    required this.god,
    required this.all,
    required this.player,
    required this.reload,
    super.key,
  });

  final God god;
  final List<Track> all;
  final PlayerController player;
  final Future<List<Track>> Function() reload;

  @override
  State<GodPage> createState() => _GodPageState();
}

class _GodPageState extends State<GodPage> {
  SubSection? sub;
  late List<Track> list;
  late List<Track> _all;

  @override
  void initState() {
    super.initState();
    _all = widget.all;
    list = tracksOf(_all, widget.god);
    widget.player.addListener(_tick);
  }

  @override
  void dispose() {
    widget.player.removeListener(_tick);
    super.dispose();
  }

  void _tick() {
    if (mounted) setState(() {});
  }

  void _select(SubSection? s) {
    setState(() {
      sub = s;
      list = s == null
          ? tracksOf(_all, widget.god)
          : tracksOfSub(_all, widget.god, s);
    });
    if (list.isNotEmpty) widget.player.playQueue(list, 0);
  }

  void _snack(String m) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));
  }

  Future<void> _cleanTrack(Track t) async {
    final o = await askCleanOptions(context);
    if (o == null || !o.any || !mounted) return;
    final dst = cleanedPathFor(t.path);
    final ok = await runCleanWithProgress(context, t.path, dst, o);
    if (!mounted) return;
    if (!ok) {
      _snack('सफ़ाई नहीं हो पाई।');
      return;
    }
    _all = await widget.reload();
    if (!mounted) return;
    setState(() {
      list = sub == null
          ? tracksOf(_all, widget.god)
          : tracksOfSub(_all, widget.god, sub!);
    });
    _snack('साफ़ की हुई कॉपी सूची में जुड़ गई। मूल भी बची है।');
  }

  Future<void> _openEditor(Track t) async {
    await Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => EditorPage(
          path: t.path,
          player: widget.player,
          onSaved: () async {
            _all = await widget.reload();
            if (!mounted) return;
            setState(() {
              list = sub == null
                  ? tracksOf(_all, widget.god)
                  : tracksOfSub(_all, widget.god, sub!);
            });
          },
        ),
      ),
    );
  }

  Future<void> _editLyrics(Track t) async {
    final ctrl = TextEditingController(text: t.lyrics);
    final saved = await showDialog<String>(
      context: context,
      builder: (c) => AlertDialog(
        title: Text('बोल: ${t.title}'),
        content: SizedBox(
          width: double.maxFinite,
          child: TextField(
            controller: ctrl,
            maxLines: 10,
            minLines: 5,
            style: const TextStyle(fontSize: 18),
            decoration: const InputDecoration(
              hintText: 'भजन के बोल या शुरू की कुछ पंक्तियाँ यहाँ लिखें या पेस्ट करें। बोलकर खोजने में काम आएँगे।',
              border: OutlineInputBorder(),
            ),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c), child: const Text('रहने दें')),
          FilledButton(onPressed: () => Navigator.pop(c, ctrl.text), child: const Text('सेव करें')),
        ],
      ),
    );
    ctrl.dispose();
    if (saved == null || !mounted) return;
    try {
      final f = File(lyricsPathFor(t.path));
      if (saved.trim().isEmpty) {
        if (f.existsSync()) f.deleteSync();
      } else {
        await f.writeAsString(saved);
      }
    } on FileSystemException catch (e) {
      _snack('बोल सेव नहीं हो पाए: ${e.message}');
      return;
    }
    _all = await widget.reload();
    if (!mounted) return;
    setState(() {
      list = sub == null
          ? tracksOf(_all, widget.god)
          : tracksOfSub(_all, widget.god, sub!);
    });
    _snack('बोल सेव हो गए। अब बोलने पर इनसे भी खोज होगी।');
  }

  Future<void> _deleteTrack(Track t) async {
    final yes = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('रिकॉर्डिंग हटाएँ?'),
        content: Text('"${t.title}" हमेशा के लिए हट जाएगी। दोबारा रिकॉर्ड कर सकते हैं।'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('रहने दें')),
          FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('हटाएँ')),
        ],
      ),
    );
    if (yes != true || !mounted) return;
    try {
      if (widget.player.current?.path == t.path) await widget.player.audio.stop();
      final f = File(t.path);
      if (await f.exists()) await f.delete();
      final l = File(lyricsPathFor(t.path));
      if (await l.exists()) await l.delete();
    } on Object {
      _snack('हट नहीं पाई।');
      return;
    }
    _all = await widget.reload();
    if (!mounted) return;
    setState(() {
      list = sub == null
          ? tracksOf(_all, widget.god)
          : tracksOfSub(_all, widget.god, sub!);
    });
    _snack('रिकॉर्डिंग हट गई।');
  }

  Future<void> _download(Track t) async {
    final ok = await copyTrack(t, downloadDir);
    _snack(ok ? '"${t.title}" Downloads फोल्डर में सेव हो गया।' : 'सेव नहीं हो पाया।');
  }

  Future<void> _copyListToUsb() async {
    if (list.isEmpty) return;
    final dest = await FilePicker.getDirectoryPath(
      dialogTitle: 'पेन ड्राइव चुनें',
    );
    if (dest == null || !mounted) return;
    final folder = widget.god.name + (sub == null ? '' : ' - ${sub!.name}');
    var ok = 0;
    for (final t in list) {
      if (await copyTrack(t, dest, subfolder: folder)) ok++;
    }
    _snack('${list.length} में से $ok फ़ाइल पेन ड्राइव में कॉपी हो गईं।');
  }

  @override
  Widget build(BuildContext context) {
    final g = widget.god;
    final p = widget.player;
    final title = g.name + (sub == null ? '' : ' — ${sub!.name}');
    return Scaffold(
      appBar: AppBar(
        backgroundColor: _saffron,
        foregroundColor: Colors.white,
        flexibleSpace: const DecoratedBox(decoration: BoxDecoration(gradient: _headerGradient)),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
      ),
      body: Column(
        children: [
          if (g.subs.isNotEmpty)
            SizedBox(
              height: 64,
              child: ListView(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.all(8),
                children: [
                  for (final s in g.subs)
                    Padding(
                      padding: const EdgeInsets.only(right: 8),
                      child: ChoiceChip(
                        label: Text(
                          '${s.name} (${tracksOfSub(_all, g, s).length})',
                          style: const TextStyle(fontSize: 17),
                        ),
                        selected: sub == s,
                        onSelected: (_) => _select(s),
                      ),
                    ),
                  Padding(
                    padding: const EdgeInsets.only(right: 8),
                    child: ChoiceChip(
                      label: Text(
                        'सभी (${tracksOf(_all, g).length})',
                        style: const TextStyle(fontSize: 17),
                      ),
                      selected: sub == null,
                      onSelected: (_) => _select(null),
                    ),
                  ),
                ],
              ),
            ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8),
            child: Wrap(
              spacing: 8,
              children: [
                FilledButton.icon(
                  onPressed: list.isEmpty ? null : () => p.playQueue(list, 0).then((_) => p.shuffleAndPlay()),
                  icon: const Icon(Icons.shuffle),
                  label: const Text('मिलाकर चलाएँ'),
                ),
                OutlinedButton.icon(
                  onPressed: list.isEmpty ? null : _copyListToUsb,
                  icon: const Icon(Icons.usb),
                  label: const Text('पेन ड्राइव में भरें'),
                ),
                OutlinedButton.icon(
                  onPressed: () => openUrl(
                    'https://www.jiosaavn.com/search/${Uri.encodeComponent(sub?.query ?? g.query)}',
                  ),
                  icon: const Icon(Icons.search),
                  label: const Text('नए भजन खोजें'),
                ),
              ],
            ),
          ),
          Expanded(
            child: list.isEmpty
                ? const Center(
                    child: Padding(
                      padding: EdgeInsets.all(24),
                      child: Text(
                        'अभी यहाँ कुछ नहीं है। भजन अपने फोल्डर में रखिए और होम पर 🔄 दबाइए।',
                        textAlign: TextAlign.center,
                        style: TextStyle(fontSize: 18),
                      ),
                    ),
                  )
                : ListView.builder(
                    padding: const EdgeInsets.fromLTRB(12, 8, 12, 8),
                    itemCount: list.length,
                    itemBuilder: (c, i) {
                      final t = list[i];
                      final playing = p.current?.path == t.path;
                      return Card(
                        margin: const EdgeInsets.only(bottom: 8),
                        color: playing ? const Color(0xFFFFE3C2) : Colors.white,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(14),
                          side: BorderSide(
                            color: playing ? _saffron : const Color(0xFFF3D9BD),
                            width: playing ? 2 : 1,
                          ),
                        ),
                        child: ListTile(
                          leading: CircleAvatar(
                            backgroundColor: playing ? _saffron : const Color(0xFFFFE3C2),
                            foregroundColor: playing ? Colors.white : const Color(0xFF9A3412),
                            child: playing
                                ? const Icon(Icons.graphic_eq)
                                : Text('${i + 1}'),
                          ),
                          title: Text(
                            t.title,
                            style: TextStyle(
                              fontSize: 19,
                              fontWeight: playing ? FontWeight.w800 : FontWeight.w600,
                            ),
                          ),
                          trailing: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              IconButton(
                                tooltip: 'बोल',
                                icon: Icon(
                                  t.lyrics.isEmpty ? Icons.notes : Icons.lyrics,
                                  color: _saffron,
                                ),
                                onPressed: () => _editLyrics(t),
                              ),
                              if (isWavPath(t.path))
                                IconButton(
                                  tooltip: 'एडिटर (काटें/जोड़ें/शोर)',
                                  icon: const Icon(Icons.content_cut, color: _saffron),
                                  onPressed: () => _openEditor(t),
                                ),
                              if (isWavPath(t.path))
                                IconButton(
                                  tooltip: 'शोर हटाएँ',
                                  icon: const Icon(Icons.auto_fix_high, color: _saffron),
                                  onPressed: () => _cleanTrack(t),
                                ),
                              if (widget.god.name == ladiesFolder)
                                IconButton(
                                  tooltip: 'हटाएँ',
                                  icon: const Icon(Icons.delete_outline, color: Colors.red),
                                  onPressed: () => _deleteTrack(t),
                                ),
                              IconButton(
                                tooltip: 'डाउनलोड',
                                icon: const Icon(Icons.download_rounded, color: _saffron),
                                onPressed: () => _download(t),
                              ),
                            ],
                          ),
                          onTap: () => p.playQueue(list, i),
                        ),
                      );
                    },
                  ),
          ),
          _MiniPlayer(player: p),
        ],
      ),
    );
  }
}

class _MiniPlayer extends StatelessWidget {
  const _MiniPlayer({required this.player});

  final PlayerController player;

  @override
  Widget build(BuildContext context) {
    final cur = player.current;
    if (cur == null) return const SizedBox.shrink();
    return Container(
      color: Colors.white,
      padding: const EdgeInsets.fromLTRB(12, 8, 12, 12),
      child: SafeArea(
        top: false,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              '▶ ${cur.title}',
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w700),
            ),
            StreamBuilder<Duration>(
              stream: player.audio.positionStream,
              builder: (c, snap) {
                final pos = snap.data ?? Duration.zero;
                final dur = player.audio.duration ?? Duration.zero;
                final max = dur.inMilliseconds.toDouble();
                final val = pos.inMilliseconds.clamp(0, dur.inMilliseconds).toDouble();
                return Slider(
                  value: max == 0 ? 0 : val,
                  max: max == 0 ? 1 : max,
                  onChanged: (v) => player.seek(Duration(milliseconds: v.round())),
                );
              },
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                IconButton(iconSize: 40, onPressed: player.previous, icon: const Icon(Icons.skip_previous)),
                IconButton(
                  iconSize: 56,
                  onPressed: player.toggle,
                  icon: Icon(player.isPlaying ? Icons.pause_circle : Icons.play_circle),
                ),
                IconButton(iconSize: 40, onPressed: player.next, icon: const Icon(Icons.skip_next)),
              ],
            ),
          ],
        ),
      ),
    );
  }
}


class SearchPage extends StatefulWidget {
  const SearchPage({required this.all, required this.player, super.key});

  final List<Track> all;
  final PlayerController player;

  @override
  State<SearchPage> createState() => _SearchPageState();
}

class _SearchPageState extends State<SearchPage> {
  final _speech = SpeechToText();
  final _ctrl = TextEditingController();
  bool _ready = false;
  bool _listening = false;
  String _status = 'माइक दबाकर बोलिए, जैसे: "सुंदरकांड लगाओ"';
  List<Track> _results = const [];

  @override
  void initState() {
    super.initState();
    widget.player.addListener(_tick);
    _initSpeech();
  }

  @override
  void dispose() {
    widget.player.removeListener(_tick);
    _speech.cancel();
    _ctrl.dispose();
    super.dispose();
  }

  void _tick() {
    if (mounted) setState(() {});
  }

  Future<void> _initSpeech() async {
    try {
      final ok = await _speech.initialize(
        onError: (e) {
          if (!mounted) return;
          setState(() {
            _listening = false;
            _status = 'सुन नहीं पाया। फिर कोशिश करें या नीचे लिखकर खोजें।';
          });
        },
        onStatus: (st) {
          if (!mounted) return;
          if (st == 'done' || st == 'notListening') {
            setState(() => _listening = false);
          }
        },
      );
      if (!mounted) return;
      setState(() {
        _ready = ok;
        if (!ok) {
          _status = 'बोलकर खोजने के लिए माइक की अनुमति और इंटरनेट चाहिए। आप लिखकर भी खोज सकते हैं।';
        }
      });
    } on Object {
      if (mounted) {
        setState(() => _status = 'इस फ़ोन पर बोलकर खोज उपलब्ध नहीं। लिखकर खोजें।');
      }
    }
  }

  Future<void> _listen() async {
    if (!_ready) {
      await _initSpeech();
      if (!_ready) return;
    }
    if (_listening) {
      await _speech.stop();
      return;
    }
    setState(() {
      _listening = true;
      _status = 'सुन रहा हूँ… बोलिए';
    });
    await _speech.listen(
      onResult: (r) {
        if (!mounted) return;
        setState(() => _ctrl.text = r.recognizedWords);
        if (r.finalResult) {
          setState(() => _listening = false);
          _search(r.recognizedWords, autoplay: true);
        }
      },
      listenOptions: SpeechListenOptions(
        partialResults: true,
        cancelOnError: true,
        localeId: 'hi_IN',
        listenFor: const Duration(seconds: 20),
        pauseFor: const Duration(seconds: 3),
      ),
    );
  }

  void _search(String q, {bool autoplay = false}) {
    final r = searchTracks(widget.all, q);
    setState(() {
      _results = r;
      _status = r.isEmpty
          ? '"$q" नहीं मिला। दूसरे शब्द आज़माएँ।'
          : '${r.length} भजन मिले${autoplay ? " — पहला चल रहा है" : ""}';
    });
    if (autoplay && r.isNotEmpty) widget.player.playQueue(r, 0);
  }

  @override
  Widget build(BuildContext context) {
    final p = widget.player;
    return Scaffold(
      appBar: AppBar(
        backgroundColor: _saffron,
        foregroundColor: Colors.white,
        flexibleSpace: const DecoratedBox(decoration: BoxDecoration(gradient: _headerGradient)),
        title: const Text('🔍 भजन खोजें', style: TextStyle(fontWeight: FontWeight.w800)),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _ctrl,
                    style: const TextStyle(fontSize: 20),
                    textInputAction: TextInputAction.search,
                    onSubmitted: (v) => _search(v, autoplay: true),
                    decoration: InputDecoration(
                      hintText: 'जैसे: सुंदरकांड, हनुमान चालीसा',
                      filled: true,
                      fillColor: Colors.white,
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
                      suffixIcon: IconButton(
                        icon: const Icon(Icons.search),
                        onPressed: () => _search(_ctrl.text, autoplay: true),
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                Material(
                  color: _listening ? Colors.red : _saffron,
                  shape: const CircleBorder(),
                  elevation: 4,
                  child: InkWell(
                    customBorder: const CircleBorder(),
                    onTap: _listen,
                    child: SizedBox(
                      width: 68,
                      height: 68,
                      child: Icon(_listening ? Icons.stop : Icons.mic, size: 36, color: Colors.white),
                    ),
                  ),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Text(_status, style: const TextStyle(fontSize: 16, color: Colors.black87)),
          ),
          const SizedBox(height: 8),
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.fromLTRB(12, 0, 12, 8),
              itemCount: _results.length,
              itemBuilder: (c, i) {
                final t = _results[i];
                final playing = p.current?.path == t.path;
                return Card(
                  margin: const EdgeInsets.only(bottom: 8),
                  color: playing ? const Color(0xFFFFE3C2) : Colors.white,
                  child: ListTile(
                    leading: CircleAvatar(
                      backgroundColor: playing ? _saffron : const Color(0xFFFFE3C2),
                      foregroundColor: playing ? Colors.white : const Color(0xFF9A3412),
                      child: playing ? const Icon(Icons.graphic_eq) : Text('${i + 1}'),
                    ),
                    title: Text(
                      t.title,
                      style: TextStyle(fontSize: 19, fontWeight: playing ? FontWeight.w800 : FontWeight.w600),
                    ),
                    subtitle: Text(t.parts.first),
                    onTap: () => p.playQueue(_results, i),
                  ),
                );
              },
            ),
          ),
          _MiniPlayer(player: p),
        ],
      ),
    );
  }
}
