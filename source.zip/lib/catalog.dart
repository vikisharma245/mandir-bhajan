/// भगवान, उनके फोल्डर पहचानने के शब्द और खोज शब्द।
class SubSection {
  const SubSection(this.name, this.keys, this.query, {this.rest = false});

  final String name;
  final List<String> keys;
  final String query;

  /// सच: जो किसी और सेक्शन में नहीं आया, वह यहाँ आएगा।
  final bool rest;
}

class God {
  const God(
    this.name,
    this.keys,
    this.query, {
    this.subs = const [],
    this.flat = false,
  });

  final String name;
  final List<String> keys;
  final String query;
  final List<SubSection> subs;

  /// सच: सारे भगवान की फ़ाइलें एक साथ (जैसे आरती)।
  final bool flat;
}

const aartiKeys = ['आरती', 'aarti', 'aarati', 'arati'];

const hanumanSubs = [
  SubSection('हनुमान चालीसा', ['चालीसा', 'chalisa'], 'हनुमान चालीसा'),
  SubSection(
    'बजरंग बाण',
    ['बजरंग बाण', 'बजरंगबाण', 'bajrangbaan', 'bajrangban'],
    'बजरंग बाण',
  ),
  SubSection(
    'संकट मोचन',
    ['संकट मोचन', 'संकटमोचन', 'sankatmochan'],
    'संकट मोचन हनुमान अष्टक',
  ),
  SubSection(
    'सुंदरकांड',
    ['सुंदरकांड', 'सुंदर कांड', 'सुन्दरकाण्ड', 'sundarkand', 'sunderkand'],
    'सुंदरकांड पाठ',
  ),
  SubSection(
    'श्री राम स्तुति',
    ['राम स्तुति', 'रामस्तुति', 'ramstuti'],
    'श्री राम स्तुति',
  ),
  SubSection(
    'भजन',
    ['भजन', 'bhajan'],
    'हनुमान जी के सुपरहिट भजन',
    rest: true,
  ),
];

const gods = <God>[
  God(
    'शिव जी',
    ['शिव', 'shiv', 'mahadev', 'महादेव', 'bholenath', 'भोलेनाथ'],
    'शिव जी के सुपरहिट भजन हिंदी',
  ),
  God(
    'गणेश जी',
    ['गणेश', 'ganesh', 'ganpati', 'गणपति'],
    'गणेश जी के सुपरहिट भजन हिंदी',
  ),
  God(
    'माँ पार्वती',
    ['पार्वती', 'parvati', 'gauri', 'गौरी'],
    'माँ पार्वती गौरी भजन हिंदी',
  ),
  God(
    'हनुमान जी',
    ['हनुमान', 'hanuman', 'bajrang', 'बजरंग'],
    'हनुमान जी भजन हिंदी',
    subs: hanumanSubs,
  ),
  God('राम जी', ['राम', 'ram', 'raam'], 'श्री राम भजन हिंदी'),
  God(
    'कृष्ण जी',
    ['कृष्ण', 'krishna', 'shyam', 'श्याम'],
    'कृष्ण भजन हिंदी',
  ),
  God(
    'माँ दुर्गा',
    ['दुर्गा', 'durga', 'mata', 'माता', 'ambe', 'अंबे'],
    'माँ दुर्गा माता भजन हिंदी',
  ),
  God(
    'माँ लक्ष्मी',
    ['लक्ष्मी', 'laxmi', 'lakshmi'],
    'माँ लक्ष्मी भजन हिंदी',
  ),
  God(
    'लेडीज़ भजन',
    ['लेडीज़', 'ladies'],
    'भजन मंडली लेडीज़ भजन हिंदी',
  ),
  God(
    'आरती',
    aartiKeys,
    'सभी देवी देवताओं की आरती हिंदी',
    flat: true,
  ),
  God(
    'श्रीमद्भगवद्गीता',
    ['गीता', 'gita'],
    'श्रीमद्भगवद्गीता पाठ हिंदी',
  ),
];
