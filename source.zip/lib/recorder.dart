import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:record/record.dart';

import 'clean_ui.dart';
import 'denoise.dart';

/// लेडीज़ के लाइव भजन की रिकॉर्डिंग का पेज।
/// रिकॉर्डिंग [root]/लेडीज़ भजन फोल्डर में सेव होती है, ताकि बाकी भजनों की तरह चले।
const ladiesFolder = 'लेडीज़ भजन';

enum _SaveChoice { discard, save, saveClean }

class RecorderPage extends StatefulWidget {
  const RecorderPage({required this.root, required this.onSaved, super.key});

  final String root;
  final VoidCallback onSaved;

  @override
  State<RecorderPage> createState() => _RecorderPageState();
}

class _RecorderPageState extends State<RecorderPage> {
  final _rec = AudioRecorder();
  bool _recording = false;
  bool _paused = false;
  bool _clean = true;
  Duration _elapsed = Duration.zero;
  Timer? _timer;

  @override
  void dispose() {
    _timer?.cancel();
    _rec.dispose();
    super.dispose();
  }

  void _snack(String m) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));
  }

  Future<void> _start() async {
    if (!await _rec.hasPermission()) {
      _snack('माइक की अनुमति चाहिए। फ़ोन की सेटिंग में ऐप को माइक की अनुमति दें।');
      return;
    }
    final tmp = '${Directory.systemTemp.path}/bhajan_rec.wav';
    try {
      await _rec.start(
        RecordConfig(
          encoder: AudioEncoder.wav,
          sampleRate: 32000,
          numChannels: 1,
          noiseSuppress: _clean,
          autoGain: _clean,
          echoCancel: _clean,
        ),
        path: tmp,
      );
    } on Object catch (e) {
      _snack('रिकॉर्डिंग शुरू नहीं हो पाई: $e');
      return;
    }
    _elapsed = Duration.zero;
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (!_paused && mounted) setState(() => _elapsed += const Duration(seconds: 1));
    });
    setState(() {
      _recording = true;
      _paused = false;
    });
  }

  Future<void> _togglePause() async {
    if (_paused) {
      await _rec.resume();
    } else {
      await _rec.pause();
    }
    setState(() => _paused = !_paused);
  }

  Future<void> _stop() async {
    _timer?.cancel();
    final path = await _rec.stop();
    setState(() {
      _recording = false;
      _paused = false;
    });
    if (path == null || !File(path).existsSync()) {
      _snack('रिकॉर्डिंग नहीं मिली।');
      return;
    }
    await _askNameAndSave(path);
  }

  String _defaultName() {
    final n = DateTime.now();
    String two(int v) => v.toString().padLeft(2, '0');
    return 'लेडीज़ भजन ${two(n.day)}-${two(n.month)} ${two(n.hour)}.${two(n.minute)}';
  }

  Future<void> _askNameAndSave(String tmp) async {
    final ctrl = TextEditingController(text: _defaultName());
    final choice = await showDialog<_SaveChoice>(
      context: context,
      barrierDismissible: false,
      builder: (c) => AlertDialog(
        title: const Text('भजन का नाम'),
        content: TextField(
          controller: ctrl,
          autofocus: true,
          style: const TextStyle(fontSize: 20),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(c, _SaveChoice.discard),
            child: const Text('हटाएँ'),
          ),
          OutlinedButton(
            onPressed: () => Navigator.pop(c, _SaveChoice.save),
            child: const Text('सेव करें'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(c, _SaveChoice.saveClean),
            child: const Text('शोर हटाकर सेव'),
          ),
        ],
      ),
    );
    final name = ctrl.text.trim();
    ctrl.dispose();
    if (choice == null || choice == _SaveChoice.discard || name.isEmpty) {
      _deleteQuietly(tmp);
      _snack('रिकॉर्डिंग हटा दी गई।');
      return;
    }
    if (!mounted) return;
    CleanOptions? opts;
    if (choice == _SaveChoice.saveClean) {
      opts = await askCleanOptions(
        context,
        initial: const CleanOptions(hum: true, rumble: true, hiss: true, normalize: true),
      );
    }
    final safe = name.replaceAll(RegExp(r'[\\/:*?"<>|]'), ' ').trim();
    try {
      final dir = Directory('${widget.root}/$ladiesFolder');
      await dir.create(recursive: true);
      var base = '${dir.path}/$safe';
      var i = 2;
      while (File('$base.wav').existsSync() || File('$base (मूल).wav').existsSync()) {
        base = '${dir.path}/$safe $i';
        i++;
      }
      if (opts != null && opts.any) {
        final original = '$base (मूल).wav';
        await File(tmp).copy(original);
        if (!mounted) return;
        final ok = await runCleanWithProgress(context, original, '$base.wav', opts);
        if (!ok) {
          _snack('सफ़ाई नहीं हो पाई, मूल रिकॉर्डिंग सेव है।');
        } else {
          _snack('सेव हो गया: "$safe" (साफ़) और "(मूल)" भी।');
        }
      } else {
        await File(tmp).copy('$base.wav');
        _snack('सेव हो गया: "$safe" — होम पर "लेडीज़ भजन" में मिलेगा।');
      }
      _deleteQuietly(tmp);
      widget.onSaved();
    } on FileSystemException catch (e) {
      _snack('सेव नहीं हो पाया: ${e.message}');
    }
  }

  void _deleteQuietly(String path) {
    try {
      File(path).deleteSync();
    } on FileSystemException {
      // अस्थायी फ़ाइल हटी नहीं तो कोई बात नहीं।
    }
  }

  String _fmt(Duration d) {
    String two(int v) => v.toString().padLeft(2, '0');
    return '${two(d.inMinutes)}:${two(d.inSeconds % 60)}';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFFE8590C),
        foregroundColor: Colors.white,
        title: const Text('🎙️ लाइव भजन रिकॉर्ड', style: TextStyle(fontWeight: FontWeight.w800)),
      ),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              _recording ? (_paused ? 'रुका हुआ' : 'रिकॉर्ड हो रहा है…') : 'माइक का बटन दबाकर शुरू करें',
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w600),
            ),
            const SizedBox(height: 12),
            Text(
              _fmt(_elapsed),
              style: const TextStyle(fontSize: 56, fontWeight: FontWeight.w800),
            ),
            const SizedBox(height: 24),
            Material(
              color: _recording ? Colors.red : const Color(0xFFE8590C),
              shape: const CircleBorder(),
              elevation: 6,
              child: InkWell(
                customBorder: const CircleBorder(),
                onTap: _recording ? _stop : _start,
                child: SizedBox(
                  width: 140,
                  height: 140,
                  child: Icon(
                    _recording ? Icons.stop : Icons.mic,
                    size: 72,
                    color: Colors.white,
                  ),
                ),
              ),
            ),
            const SizedBox(height: 16),
            if (_recording)
              OutlinedButton.icon(
                onPressed: _togglePause,
                icon: Icon(_paused ? Icons.play_arrow : Icons.pause),
                label: Text(_paused ? 'फिर शुरू करें' : 'रोकें'),
              ),
            const SizedBox(height: 24),
            SwitchListTile(
              value: _clean,
              onChanged: _recording ? null : (v) => setState(() => _clean = v),
              title: const Text('आवाज़ साफ़ करें', style: TextStyle(fontSize: 18)),
              subtitle: const Text(
                'रिकॉर्डिंग के समय शोर कम करना और आवाज़ बराबर रखना। असर फ़ोन पर निर्भर है।',
              ),
            ),
            const SizedBox(height: 8),
            const Text(
              'रोकने के बाद नाम डालकर सेव करें। सेव हुई रिकॉर्डिंग होम के "लेडीज़ भजन" में बाकी भजनों की तरह चलेगी।',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 15, color: Colors.black54),
            ),
          ],
        ),
      ),
    );
  }
}
