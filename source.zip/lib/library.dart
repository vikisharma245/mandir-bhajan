import 'dart:io';

import 'catalog.dart';

/// एक ऑडियो फ़ाइल: नाम, फोल्डर-कड़ियाँ (भगवान का फोल्डर पहला) और पूरा पता।
class Track {
  const Track({
    required this.name,
    required this.parts,
    required this.path,
    this.lyrics = '',
  });

  final String name;
  final List<String> parts;
  final String path;

  /// भजन के बोल (साथ वाली .txt फ़ाइल से), खोज में काम आते हैं।
  final String lyrics;

  String get fileName => parts.last;

  /// सूची में दिखने वाला सुंदर नाम (जैसे "सुंदरकांड", "हनुमान चालीसा")।
  String get title => prettyTitle(name);
}

final _audioExt = RegExp(r'\.(mp3|m4a|aac|wav|ogg|opus|flac|wma)$', caseSensitive: false);
final _stripNoise = RegExp(r'[\s_\-\.\(\)]+');

String norm(String s) => s.toLowerCase().replaceAll(_stripNoise, '');

bool hit(String text, List<String> keys) {
  final t = norm(text);
  return keys.any((k) => t.contains(norm(k)));
}

/// भजन के साथ वाली बोल की फ़ाइल का पता (नाम वही, अंत .txt)।
String lyricsPathFor(String audioPath) {
  final i = audioPath.lastIndexOf('.');
  return '${i > 0 ? audioPath.substring(0, i) : audioPath}.txt';
}

/// फोल्डर (अधिकतम 4 स्तर) में सारे ऑडियो ढूँढता है।
Future<List<Track>> scanLibrary(String root) async {
  final dir = Directory(root);
  if (!await dir.exists()) return const [];
  final raw = <Track>[];
  final lyricFiles = <String>{};
  final base = dir.path.endsWith('/') ? dir.path : '${dir.path}/';
  try {
    await for (final e in dir.list(recursive: true, followLinks: false)) {
      if (e is! File) continue;
      if (e.path.toLowerCase().endsWith('.txt')) {
        lyricFiles.add(e.path);
        continue;
      }
      if (!_audioExt.hasMatch(e.path)) continue;
      final rel = e.path.startsWith(base) ? e.path.substring(base.length) : e.path;
      final parts = rel.split('/');
      if (parts.length > 5) continue;
      raw.add(
        Track(
          name: parts.last.replaceAll(RegExp(r'\.[^.]+$'), ''),
          parts: parts,
          path: e.path,
        ),
      );
    }
  } on FileSystemException {
    // कुछ फोल्डर पढ़े नहीं जा सके तो जितना मिला उतना दिखाएँ।
  }
  final out = <Track>[];
  for (final t in raw) {
    var text = '';
    final lp = lyricsPathFor(t.path);
    if (lyricFiles.contains(lp)) {
      try {
        text = await File(lp).readAsString();
      } on Object {
        text = '';
      }
    }
    out.add(Track(name: t.name, parts: t.parts, path: t.path, lyrics: text));
  }
  out.sort((a, b) => a.name.toLowerCase().compareTo(b.name.toLowerCase()));
  return out;
}

bool _isAarti(Track t) => hit(t.parts.join('/'), aartiKeys);

/// भगवान की सारी फ़ाइलें।
List<Track> tracksOf(List<Track> all, God g) {
  if (g.flat) return all.where(_isAarti).toList();
  return all
      .where((t) => t.parts.length > 1 && !_isAarti(t) && hit(t.parts.first, g.keys))
      .toList();
}

/// भगवान के एक सेक्शन की फ़ाइलें (जैसे हनुमान चालीसा)।
List<Track> tracksOfSub(List<Track> all, God g, SubSection s) {
  final base = tracksOf(all, g);
  final others = g.subs.where((x) => !x.rest).toList();
  bool inSub(Track t, SubSection x) => hit(t.parts.skip(1).join('/'), x.keys);
  if (s.rest) {
    return base.where((t) => !others.any((x) => inSub(t, x))).toList();
  }
  return base.where((t) => inSub(t, s)).toList();
}

const _knownTitles = <(String, String)>[
  ('aartikijey', 'आरती कीजे हनुमान लला की'),
  ('hanumanaarti', 'श्री हनुमान जी की आरती'),
  ('chalisa', 'हनुमान चालीसा'),
  ('bajrangban', 'बजरंग बाण'),
  ('sunderkand', 'सुंदरकांड'),
  ('sankatmochan', 'संकट मोचन'),
  ('austak', 'हनुमान अष्टक'),
  ('ashtak', 'हनुमान अष्टक'),
  ('stavan', 'हनुमान स्तवन'),
  ('aajmangalvaar', 'आज मंगलवार है'),
  ('chhand', 'हनुमान छंद'),
];

const _seriesTitles = <String, String>{
  'aartivandan': 'आरती वंदन',
  'aarti': 'आरती',
  'krishnabhajans': 'कृष्ण जी के भजन',
  'shivganga': 'शिव जी और गंगा जी भजन',
  'srimadbhagavadgita': 'श्रीमद्भगवद्गीता भाग',
};

/// फ़ाइल के नाम से पढ़ने लायक नाम बनाता है।
String prettyTitle(String stem) {
  final n = norm(stem);
  for (final (key, title) in _knownTitles) {
    if (n.contains(key)) return title;
  }
  final series = RegExp(r'^(.*?)(\d+)$').firstMatch(norm(stem));
  if (series != null) {
    final base = series.group(1)!;
    final label = _seriesTitles[base];
    if (label != null) return '$label ${int.parse(series.group(2)!)}';
  }
  var t = stem.replaceFirst(RegExp(r'^[A-Za-z_]+-\d+-'), '');
  t = t.replaceAll('_', ' ').replaceAll(RegExp(r'\s+'), ' ').trim();
  return t.isEmpty ? stem : t;
}

const _commandWords = <String>{
  'लगाओ', 'लगाइए', 'लगाइये', 'लगाना', 'लगा', 'दो', 'दीजिए', 'दीजिये', 'चलाओ',
  'चलाइए', 'चलाइये', 'चलाना', 'चला', 'सुनाओ', 'सुनाइए', 'सुनाइये', 'सुनाना',
  'बजाओ', 'बजाइए', 'बजाना', 'सुनना', 'है', 'चाहिए', 'करो', 'कीजिए', 'कीजिये',
  'का', 'की', 'के', 'को', 'जी', 'प्लीज', 'please', 'play', 'प्ले', 'पाठ', 'भजन',
  'गाना', 'एक', 'मुझे', 'हमें', 'और', 'कुछ', 'ही', 'से', 'में', 'यह', 'वो', 'ये',
  'पर', 'भी', 'हो', 'ना', 'तो', 'अब', 'फिर',
};

/// बोले या लिखे शब्दों से मिलते भजन ढूँढता है (सबसे अच्छा मेल सबसे ऊपर)।
List<Track> searchTracks(List<Track> all, String raw) {
  final words = raw
      .replaceAll(RegExp(r'[,.!?।]'), ' ')
      .split(RegExp(r'\s+'))
      .where((w) => w.isNotEmpty)
      .toList();
  var tokens = words.where((w) => !_commandWords.contains(w.toLowerCase())).toList();
  if (tokens.isEmpty) tokens = words;
  final q = norm(tokens.join());
  if (q.isEmpty) return const [];

  bool matches(Track t) => norm('${t.title}/${t.parts.join('/')}').contains(q);
  final direct = all.where(matches).toList();
  if (direct.isNotEmpty) return direct;

  // भजन के बोल से मेल: बोले गए शब्दों में से ज़्यादातर बोल में हों।
  final qTokens = [for (final t in tokens) norm(t)].where((t) => t.length >= 2).toList();
  if (qTokens.isNotEmpty) {
    final lyric = <(double, Track)>[];
    for (final t in all) {
      if (t.lyrics.isEmpty) continue;
      final hay = norm(t.lyrics);
      if (hay.contains(q)) {
        lyric.add((2.0, t));
        continue;
      }
      final hit = qTokens.where(hay.contains).length;
      final ratio = hit / qTokens.length;
      if (hit >= (qTokens.length == 1 ? 1 : 2) && ratio >= 0.6) lyric.add((ratio, t));
    }
    if (lyric.isNotEmpty) {
      lyric.sort((a, b) => b.$1.compareTo(a.$1));
      return [for (final e in lyric) e.$2];
    }
  }

  bool keyHit(List<String> keys) => keys.any((k) {
        final nk = norm(k);
        return nk.isNotEmpty && (q.contains(nk) || (q.length >= 3 && nk.contains(q)));
      });

  for (final g in gods) {
    for (final s in g.subs.where((x) => !x.rest)) {
      if (keyHit(s.keys)) {
        final r = tracksOfSub(all, g, s);
        if (r.isNotEmpty) return r;
      }
    }
  }
  for (final g in gods) {
    if (keyHit(g.keys)) {
      final r = tracksOf(all, g);
      if (r.isNotEmpty) return r;
    }
  }

  final scored = <(int, Track)>[];
  for (final t in all) {
    final hay = norm('${t.title}/${t.parts.join('/')}');
    var score = 0;
    for (final tok in tokens) {
      final nt = norm(tok);
      if (nt.length >= 3 && hay.contains(nt)) score++;
    }
    if (score > 0) scored.add((score, t));
  }
  scored.sort((a, b) => b.$1.compareTo(a.$1));
  return [for (final e in scored) e.$2];
}
