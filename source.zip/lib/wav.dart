import 'dart:io';
import 'dart:typed_data';

/// 16-बिट PCM WAV की मोनो आवाज़ और उसकी सैंपल दर।
class WavAudio {
  const WavAudio(this.samples, this.sampleRate);

  final Float64List samples;
  final int sampleRate;
}

/// WAV पढ़ता है (16-बिट PCM; स्टीरियो हो तो दोनों चैनल का औसत लेता है)।
WavAudio readWav(String path) {
  final b = File(path).readAsBytesSync();
  final d = ByteData.sublistView(b);
  if (b.length < 44 || String.fromCharCodes(b.sublist(0, 4)) != 'RIFF') {
    throw const FormatException('यह WAV फ़ाइल नहीं है');
  }
  var pos = 12;
  var channels = 1;
  var rate = 44100;
  var bits = 16;
  int? dataStart;
  var dataLen = 0;
  while (pos + 8 <= b.length) {
    final id = String.fromCharCodes(b.sublist(pos, pos + 4));
    final len = d.getUint32(pos + 4, Endian.little);
    if (id == 'fmt ') {
      channels = d.getUint16(pos + 10, Endian.little);
      rate = d.getUint32(pos + 12, Endian.little);
      bits = d.getUint16(pos + 22, Endian.little);
    } else if (id == 'data') {
      dataStart = pos + 8;
      dataLen = len;
      if (dataStart + dataLen > b.length) dataLen = b.length - dataStart;
      break;
    }
    pos += 8 + len + (len.isOdd ? 1 : 0);
  }
  if (dataStart == null || bits != 16) {
    throw const FormatException('सिर्फ़ 16-बिट WAV समर्थित है');
  }
  final frames = dataLen ~/ (2 * channels);
  final out = Float64List(frames);
  for (var i = 0; i < frames; i++) {
    var sum = 0.0;
    for (var c = 0; c < channels; c++) {
      sum += d.getInt16(dataStart + (i * channels + c) * 2, Endian.little);
    }
    out[i] = sum / channels / 32768.0;
  }
  return WavAudio(out, rate);
}

/// मोनो 16-बिट WAV लिखता है।
void writeWav(String path, Float64List samples, int sampleRate) {
  final n = samples.length;
  final bytes = ByteData(44 + n * 2);
  void tag(int off, String s) {
    for (var i = 0; i < 4; i++) {
      bytes.setUint8(off + i, s.codeUnitAt(i));
    }
  }

  tag(0, 'RIFF');
  bytes.setUint32(4, 36 + n * 2, Endian.little);
  tag(8, 'WAVE');
  tag(12, 'fmt ');
  bytes.setUint32(16, 16, Endian.little);
  bytes.setUint16(20, 1, Endian.little);
  bytes.setUint16(22, 1, Endian.little);
  bytes.setUint32(24, sampleRate, Endian.little);
  bytes.setUint32(28, sampleRate * 2, Endian.little);
  bytes.setUint16(32, 2, Endian.little);
  bytes.setUint16(34, 16, Endian.little);
  tag(36, 'data');
  bytes.setUint32(40, n * 2, Endian.little);
  for (var i = 0; i < n; i++) {
    final v = (samples[i] * 32767.0).round().clamp(-32768, 32767);
    bytes.setInt16(44 + i * 2, v, Endian.little);
  }
  File(path).writeAsBytesSync(bytes.buffer.asUint8List());
}
