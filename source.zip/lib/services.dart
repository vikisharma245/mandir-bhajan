import 'dart:convert';
import 'dart:io';

import 'package:http/http.dart' as http;
import 'package:package_info_plus/package_info_plus.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'library.dart';

const defaultRoot = '/storage/emulated/0/Bhajan';
const downloadDir = '/storage/emulated/0/Download';
const githubRepo = 'vikisharma245/mandir-bhajan';
const freeSiteUrl = 'https://www.hanumanchalisa.org/mp3/';

Future<String> loadRoot() async {
  final p = await SharedPreferences.getInstance();
  return p.getString('root') ?? defaultRoot;
}

Future<void> saveRoot(String path) async {
  final p = await SharedPreferences.getInstance();
  await p.setString('root', path);
}

/// सभी फ़ाइलों की अनुमति (Android 11+) माँगता है; मिल गई तो सच।
Future<bool> ensureStorageAccess() async {
  if (await Permission.manageExternalStorage.isGranted) return true;
  final r = await Permission.manageExternalStorage.request();
  if (r.isGranted) return true;
  final legacy = await Permission.storage.request();
  return legacy.isGranted;
}

/// फ़ाइल को [destDir] (और चाहें तो उसके अंदर [subfolder]) में कॉपी करता है।
Future<bool> copyTrack(Track t, String destDir, {String? subfolder}) async {
  try {
    final dir = subfolder == null ? destDir : '$destDir/$subfolder';
    await Directory(dir).create(recursive: true);
    await File(t.path).copy('$dir/${t.fileName}');
    return true;
  } on FileSystemException {
    return false;
  }
}

/// पूरे ढाँचे के साथ कॉपी (पेन ड्राइव में "सब कुछ" के लिए)।
Future<bool> copyTrackKeepingFolders(Track t, String destDir) async {
  try {
    final rel = t.parts.sublist(0, t.parts.length - 1).join('/');
    final dir = rel.isEmpty ? destDir : '$destDir/$rel';
    await Directory(dir).create(recursive: true);
    await File(t.path).copy('$dir/${t.fileName}');
    return true;
  } on FileSystemException {
    return false;
  }
}

class UpdateInfo {
  const UpdateInfo({required this.version, required this.url, required this.notes});

  final String version;
  final String url;
  final String notes;
}

List<int> _ver(String v) => v
    .replaceAll(RegExp(r'[^0-9.]'), '')
    .split('.')
    .where((e) => e.isNotEmpty)
    .map((e) => int.tryParse(e) ?? 0)
    .toList();

bool _newer(String a, String b) {
  final x = _ver(a);
  final y = _ver(b);
  for (var i = 0; i < 3; i++) {
    final p = i < x.length ? x[i] : 0;
    final q = i < y.length ? y[i] : 0;
    if (p != q) return p > q;
  }
  return false;
}

/// GitHub Releases में नया वर्शन है तो उसकी जानकारी लौटाता है, नहीं तो null।
Future<UpdateInfo?> checkForUpdate() async {
  try {
    final info = await PackageInfo.fromPlatform();
    final res = await http
        .get(
          Uri.parse('https://api.github.com/repos/$githubRepo/releases/latest'),
          headers: {'Accept': 'application/vnd.github+json'},
        )
        .timeout(const Duration(seconds: 12));
    if (res.statusCode != 200) return null;
    final j = jsonDecode(res.body) as Map<String, dynamic>;
    final tag = (j['tag_name'] as String?) ?? '';
    if (!_newer(tag, info.version)) return null;
    final assets = (j['assets'] as List?) ?? const [];
    String? apk;
    for (final a in assets) {
      final m = a as Map<String, dynamic>;
      final name = (m['name'] as String?) ?? '';
      if (name.endsWith('.apk')) {
        apk = m['browser_download_url'] as String?;
        break;
      }
    }
    return UpdateInfo(
      version: tag,
      url: apk ?? (j['html_url'] as String? ?? ''),
      notes: (j['body'] as String?) ?? '',
    );
  } on Object {
    return null;
  }
}
