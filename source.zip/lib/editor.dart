import 'dart:async';
import 'dart:io';
import 'dart:isolate';
import 'dart:math' as math;
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';

import 'denoise.dart';
import 'player.dart';
import 'wav.dart';

const _saffron = Color(0xFFE8590C);
const _blk = 256;

/// रिकॉर्डिंग का वेवफ़ॉर्म एडिटर: तरंग दिखती है, हिस्सा चुनकर काट/कॉपी/पेस्ट/हटा सकते हैं,
/// शोर कम-ज़्यादा कर सकते हैं, बाँट सकते हैं, और हर कदम वापस (undo) हो सकता है।
class EditorPage extends StatefulWidget {
  const EditorPage({
    required this.path,
    required this.player,
    required this.onSaved,
    super.key,
  });

  final String path;
  final PlayerController player;
  final Future<void> Function() onSaved;

  @override
  State<EditorPage> createState() => _EditorPageState();
}

class _EditorPageState extends State<EditorPage> {
  Float64List _s = Float64List(0);
  int _rate = 32000;
  bool _loading = true;
  bool _busy = false;
  bool _dirty = false;
  bool _tmpStale = true;
  String? _error;

  final _undo = <Float64List>[];
  final _redo = <Float64List>[];
  Float64List? _clip;

  int? _a;
  int? _b;
  int _cur = 0;
  int _playPos = 0;
  int? _stopAt;

  double _spp = 256;
  double _start = 0;
  double _width = 300;
  bool _needFit = true;

  Float32List _mn = Float32List(0);
  Float32List _mx = Float32List(0);

  final AudioPlayer _ap = AudioPlayer();
  StreamSubscription<Duration>? _posSub;
  String? _tmp;

  String get _name => widget.path.split('/').last;

  @override
  void initState() {
    super.initState();
    widget.player.audio.pause();
    _posSub = _ap.positionStream.listen(_onPos);
    _load();
  }

  @override
  void dispose() {
    _posSub?.cancel();
    _ap.dispose();
    final t = _tmp;
    if (t != null) {
      try {
        File(t).deleteSync();
      } on Object {
        // ठीक है
      }
    }
    super.dispose();
  }

  Future<void> _load() async {
    try {
      final path = widget.path;
      final w = await Isolate.run(() => readWav(path));
      _s = w.samples;
      _rate = w.sampleRate;
      _rebuildPeaks();
    } on Object catch (e) {
      _error = 'फ़ाइल खुल नहीं पाई ($e)';
    }
    if (mounted) setState(() => _loading = false);
  }

  void _rebuildPeaks() {
    final n = (_s.length + _blk - 1) ~/ _blk;
    _mn = Float32List(n);
    _mx = Float32List(n);
    for (var b = 0; b < n; b++) {
      final lo = b * _blk;
      final hi = math.min(lo + _blk, _s.length);
      var mn = 1.0;
      var mx = -1.0;
      for (var i = lo; i < hi; i++) {
        final v = _s[i];
        if (v < mn) mn = v;
        if (v > mx) mx = v;
      }
      _mn[b] = mn;
      _mx[b] = mx;
    }
  }

  void _fitAll() {
    _spp = math.max(1.0, _s.length / math.max(1.0, _width));
    _start = 0;
  }

  double get _maxStart => math.max(0.0, _s.length - _width * _spp);

  void _snack(String m) {
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(m)));
  }

  String _fmt(int sample) {
    final sec = sample / _rate;
    final m = sec ~/ 60;
    final s = sec - m * 60;
    return '${m.toString().padLeft(2, '0')}:${s.toStringAsFixed(1).padLeft(4, '0')}';
  }

  // ---------- चयन ----------
  bool get _hasSel => _a != null && _b != null && _b! > _a!;

  int _sampleAt(double dx) =>
      (_start + dx * _spp).round().clamp(0, _s.length);

  void _setSel(int p, int q) {
    setState(() {
      _a = math.min(p, q);
      _b = math.max(p, q);
    });
  }

  // ---------- बदलाव और अनडू ----------
  void _apply(Float64List next, {int? cur}) {
    _undo.add(_s);
    if (_undo.length > 8) _undo.removeAt(0);
    _redo.clear();
    _s = next;
    _a = null;
    _b = null;
    _cur = (cur ?? _cur).clamp(0, _s.length);
    _tmpStale = true;
    _dirty = true;
    _rebuildPeaks();
    if (_start > _maxStart) _start = _maxStart;
    setState(() {});
  }

  void _undoOp() {
    if (_undo.isEmpty) return;
    _redo.add(_s);
    _s = _undo.removeLast();
    _afterHistory();
  }

  void _redoOp() {
    if (_redo.isEmpty) return;
    _undo.add(_s);
    _s = _redo.removeLast();
    _afterHistory();
  }

  void _afterHistory() {
    _a = null;
    _b = null;
    _cur = _cur.clamp(0, _s.length);
    _tmpStale = true;
    _dirty = true;
    _rebuildPeaks();
    if (_start > _maxStart) _start = _maxStart;
    setState(() {});
  }

  Float64List _concat(List<Float64List> parts) {
    var n = 0;
    for (final p in parts) {
      n += p.length;
    }
    final out = Float64List(n);
    var o = 0;
    for (final p in parts) {
      out.setRange(o, o + p.length, p);
      o += p.length;
    }
    return out;
  }

  Float64List _slice(int a, int b) => Float64List.fromList(_s.sublist(a, b));

  void _copy() {
    if (!_hasSel) return _snack('पहले तरंग पर उँगली खिसकाकर हिस्सा चुनिए।');
    _clip = _slice(_a!, _b!);
    _snack('कॉपी हो गया (${_fmt(_b! - _a!)})।');
  }

  void _delete() {
    if (!_hasSel) return _snack('पहले हिस्सा चुनिए।');
    final a = _a!;
    _apply(_concat([_slice(0, a), _slice(_b!, _s.length)]), cur: a);
  }

  void _cut() {
    if (!_hasSel) return _snack('पहले हिस्सा चुनिए।');
    _clip = _slice(_a!, _b!);
    _delete();
  }

  void _paste() {
    final c = _clip;
    if (c == null) return _snack('पहले कुछ कॉपी या कट कीजिए।');
    final from = _hasSel ? _a! : _cur;
    final to = _hasSel ? _b! : _cur;
    _apply(_concat([_slice(0, from), c, _slice(to, _s.length)]), cur: from + c.length);
  }

  void _silence() {
    if (!_hasSel) return _snack('पहले हिस्सा चुनिए।');
    final n = Float64List.fromList(_s);
    n.fillRange(_a!, _b!, 0);
    _apply(n);
  }

  void _trim() {
    if (!_hasSel) return _snack('पहले हिस्सा चुनिए।');
    _apply(_slice(_a!, _b!), cur: 0);
    _fitAll();
    setState(() {});
  }

  void _fade({required bool fadeIn}) {
    final a = _hasSel ? _a! : 0;
    final b = _hasSel ? _b! : _s.length;
    if (b - a < 2) return;
    final n = Float64List.fromList(_s);
    final len = b - a;
    for (var i = 0; i < len; i++) {
      final g = fadeIn ? i / len : 1 - i / len;
      n[a + i] *= g;
    }
    _apply(n);
  }

  Future<void> _gain() async {
    var pct = 100.0;
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => StatefulBuilder(
        builder: (c, set) => AlertDialog(
          title: Text(_hasSel ? 'चुने हिस्से की आवाज़' : 'पूरी आवाज़'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text('${pct.round()}%', style: const TextStyle(fontSize: 24)),
              Slider(
                value: pct,
                min: 0,
                max: 300,
                divisions: 60,
                onChanged: (v) => set(() => pct = v),
              ),
              const Text('100% = जैसी है वैसी'),
            ],
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('रद्द')),
            FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('लगाएँ')),
          ],
        ),
      ),
    );
    if (ok != true || !mounted) return;
    final a = _hasSel ? _a! : 0;
    final b = _hasSel ? _b! : _s.length;
    final g = pct / 100;
    final n = Float64List.fromList(_s);
    for (var i = a; i < b; i++) {
      n[i] = (n[i] * g).clamp(-1.0, 1.0);
    }
    _apply(n);
  }

  Future<void> _normalizeAll() async {
    var peak = 0.0;
    for (final v in _s) {
      final x = v.abs();
      if (x > peak) peak = x;
    }
    if (peak < 1e-4) return;
    final g = 0.89 / peak;
    final n = Float64List(_s.length);
    for (var i = 0; i < _s.length; i++) {
      n[i] = _s[i] * g;
    }
    _apply(n);
  }

  // ---------- शोर घटाना ----------
  Future<void> _noise() async {
    var strength = 50.0;
    var onlySel = false;
    var learnFromSel = false;
    var rumble = true;
    var hum = false;
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => StatefulBuilder(
        builder: (c, set) => AlertDialog(
          title: const Text('शोर घटाएँ'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('ताकत: ${strength.round()}%', style: const TextStyle(fontSize: 20)),
                Slider(
                  value: strength,
                  min: 0,
                  max: 100,
                  divisions: 20,
                  onChanged: (v) => set(() => strength = v),
                ),
                const Text(
                  'कम ताकत: आवाज़ साफ़ रहती है, थोड़ा शोर बचता है।\n'
                  'ज़्यादा ताकत: शोर कम, पर आवाज़ दबी/रोबोट जैसी हो सकती है।',
                  style: TextStyle(fontSize: 13),
                ),
                const SizedBox(height: 8),
                CheckboxListTile(
                  contentPadding: EdgeInsets.zero,
                  value: learnFromSel,
                  onChanged: _hasSel ? (v) => set(() => learnFromSel = v ?? false) : null,
                  title: const Text('चुना हुआ हिस्सा सिर्फ़ शोर का नमूना है'),
                  subtitle: const Text('जहाँ कोई नहीं गा रहा, वह हिस्सा चुनें; सबसे बढ़िया नतीजा'),
                ),
                CheckboxListTile(
                  contentPadding: EdgeInsets.zero,
                  value: onlySel && !learnFromSel,
                  onChanged: (_hasSel && !learnFromSel) ? (v) => set(() => onlySel = v ?? false) : null,
                  title: const Text('सिर्फ़ चुने हिस्से पर लगाएँ'),
                ),
                CheckboxListTile(
                  contentPadding: EdgeInsets.zero,
                  value: rumble,
                  onChanged: (v) => set(() => rumble = v ?? false),
                  title: const Text('नीची गड़गड़ाहट हटाएँ'),
                ),
                CheckboxListTile(
                  contentPadding: EdgeInsets.zero,
                  value: hum,
                  onChanged: (v) => set(() => hum = v ?? false),
                  title: const Text('बिजली की भिनभिनाहट हटाएँ'),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('रद्द')),
            FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('लगाएँ')),
          ],
        ),
      ),
    );
    if (ok != true || !mounted) return;

    final t = strength / 100;
    final hissStrength = 0.4 + 2.6 * t;
    final hissFloor = 0.30 - 0.25 * t;
    final opts = CleanOptions(hum: hum, rumble: rumble, hiss: strength > 0);
    final applyOnSel = onlySel && !learnFromSel && _hasSel;
    final a = applyOnSel ? _a! : 0;
    final b = applyOnSel ? _b! : _s.length;
    final target = _slice(a, b);
    final sample = (learnFromSel && _hasSel) ? _slice(_a!, _b!) : null;
    final rate = _rate;

    setState(() => _busy = true);
    Float64List cleaned;
    try {
      cleaned = await Isolate.run(
        () => cleanAudio(
          target,
          rate,
          opts,
          hissStrength: hissStrength,
          hissFloor: hissFloor,
          noiseSample: sample,
        ),
      );
    } on Object {
      if (mounted) {
        setState(() => _busy = false);
        _snack('शोर घटाना नहीं हो पाया।');
      }
      return;
    }
    if (!mounted) return;
    setState(() => _busy = false);
    _apply(_concat([_slice(0, a), cleaned, _slice(b, _s.length)]));
    _snack('हो गया। ठीक न लगे तो ↶ दबाकर वापस जाइए और ताकत बदलिए।');
  }

  // ---------- चलाना ----------
  void _onPos(Duration d) {
    final s = (d.inMicroseconds * _rate / 1e6).round();
    final stop = _stopAt;
    if (stop != null && s >= stop) {
      _stopAt = null;
      _ap.pause();
    }
    if (!mounted) return;
    setState(() {
      _playPos = s;
      if (_ap.playing && (s < _start || s > _start + _width * _spp)) {
        _start = (s - _width * _spp * 0.1).clamp(0.0, _maxStart);
      }
    });
  }

  Future<void> _ensureTmp() async {
    if (!_tmpStale && _tmp != null) return;
    _tmp ??= '${Directory.systemTemp.path}/edit_preview_${DateTime.now().microsecondsSinceEpoch}.wav';
    final path = _tmp!;
    final data = _s;
    final rate = _rate;
    await Isolate.run(() => writeWav(path, data, rate));
    _tmpStale = false;
  }

  Future<void> _play({required bool selection}) async {
    if (_s.isEmpty) return;
    await widget.player.audio.pause();
    await _ensureTmp();
    final from = selection && _hasSel ? _a! : _cur;
    _stopAt = selection && _hasSel ? _b! : null;
    await _ap.setFilePath(
      _tmp!,
      initialPosition: Duration(microseconds: (from * 1e6 / _rate).round()),
    );
    await _ap.play();
  }

  Future<void> _stop() async {
    _stopAt = null;
    await _ap.pause();
    if (mounted) setState(() => _cur = _playPos.clamp(0, _s.length));
  }

  // ---------- सेव और बाँटना ----------
  String _basePath() {
    final i = widget.path.lastIndexOf('.');
    return i > 0 ? widget.path.substring(0, i) : widget.path;
  }

  String _uniquePath(String suffix) {
    var out = '${_basePath()} ($suffix).wav';
    var n = 2;
    while (File(out).existsSync()) {
      out = '${_basePath()} ($suffix $n).wav';
      n++;
    }
    return out;
  }

  Future<void> _save() async {
    final choice = await showDialog<String>(
      context: context,
      builder: (c) => SimpleDialog(
        title: const Text('सेव कैसे करें?'),
        children: [
          SimpleDialogOption(
            onPressed: () => Navigator.pop(c, 'new'),
            child: const Text('📄 नई कॉपी बनाएँ (मूल सुरक्षित रहेगी)', style: TextStyle(fontSize: 17)),
          ),
          SimpleDialogOption(
            onPressed: () => Navigator.pop(c, 'over'),
            child: const Text('♻️ इसी फ़ाइल को बदल दें', style: TextStyle(fontSize: 17)),
          ),
        ],
      ),
    );
    if (choice == null || !mounted) return;
    final dst = choice == 'over' ? widget.path : _uniquePath('संपादित');
    setState(() => _busy = true);
    final data = _s;
    final rate = _rate;
    try {
      await Isolate.run(() => writeWav(dst, data, rate));
      await widget.onSaved();
      _dirty = false;
      if (mounted) _snack('सेव हो गया: ${dst.split('/').last}');
    } on Object {
      if (mounted) _snack('सेव नहीं हो पाया।');
    }
    if (mounted) setState(() => _busy = false);
  }

  Future<void> _split() async {
    if (_cur <= 0 || _cur >= _s.length) {
      return _snack('तरंग पर जहाँ से बाँटना है वहाँ एक बार छुइए (लाल रेखा), फिर "बाँटें" दबाइए।');
    }
    final p1 = _uniquePath('भाग 1');
    final p2 = _uniquePath('भाग 2');
    final first = _slice(0, _cur);
    final second = _slice(_cur, _s.length);
    final rate = _rate;
    setState(() => _busy = true);
    try {
      await Isolate.run(() {
        writeWav(p1, first, rate);
        writeWav(p2, second, rate);
      });
      await widget.onSaved();
      if (mounted) _snack('दो अलग फ़ाइलें बन गईं: भाग 1 और भाग 2।');
    } on Object {
      if (mounted) _snack('बाँटना नहीं हो पाया।');
    }
    if (mounted) setState(() => _busy = false);
  }

  Future<bool> _confirmLeave() async {
    final r = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('बदलाव सेव नहीं हुए'),
        content: const Text('बिना सेव किए निकलें?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('रुकें')),
          FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('निकलें')),
        ],
      ),
    );
    return r ?? false;
  }

  // ---------- ज़ूम ----------
  void _zoom(double factor) {
    final center = _start + _width * _spp / 2;
    final minSpp = 1.0;
    final maxSpp = math.max(1.0, _s.length / math.max(1.0, _width));
    _spp = (_spp * factor).clamp(minSpp, maxSpp);
    _start = (center - _width * _spp / 2).clamp(0.0, _maxStart);
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: !_dirty,
      onPopInvokedWithResult: (didPop, _) async {
        if (didPop) return;
        final nav = Navigator.of(context);
        if (await _confirmLeave()) nav.pop();
      },
      child: Scaffold(
        backgroundColor: const Color(0xFFFFF7EC),
        appBar: AppBar(
          backgroundColor: _saffron,
          foregroundColor: Colors.white,
          title: Text('एडिटर — $_name', style: const TextStyle(fontSize: 16)),
          actions: [
            IconButton(
              tooltip: 'वापस (undo)',
              onPressed: _undo.isEmpty ? null : _undoOp,
              icon: const Icon(Icons.undo),
            ),
            IconButton(
              tooltip: 'फिर से (redo)',
              onPressed: _redo.isEmpty ? null : _redoOp,
              icon: const Icon(Icons.redo),
            ),
            IconButton(
              tooltip: 'सेव',
              onPressed: _busy || _s.isEmpty ? null : _save,
              icon: const Icon(Icons.save),
            ),
          ],
        ),
        body: _loading
            ? const Center(child: CircularProgressIndicator())
            : _error != null
                ? Center(child: Padding(padding: const EdgeInsets.all(24), child: Text(_error!)))
                : _body(),
      ),
    );
  }

  Widget _body() {
    return Column(
      children: [
        if (_busy) const LinearProgressIndicator(),
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 8, 12, 0),
          child: Text(
            'कुल ${_fmt(_s.length)}   |   लाल रेखा ${_fmt(_cur)}'
            '${_hasSel ? '   |   चुना ${_fmt(_a!)} → ${_fmt(_b!)} (${_fmt(_b! - _a!)})' : ''}',
            style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600),
          ),
        ),
        Container(
          height: 200,
          margin: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: Colors.white,
            border: Border.all(color: const Color(0xFFF3D9BD)),
            borderRadius: BorderRadius.circular(12),
          ),
          clipBehavior: Clip.antiAlias,
          child: LayoutBuilder(
            builder: (context, c) {
              _width = c.maxWidth;
              if (_needFit) {
                _needFit = false;
                _fitAll();
              }
              return GestureDetector(
                behavior: HitTestBehavior.opaque,
                onTapUp: (d) {
                  setState(() {
                    _cur = _sampleAt(d.localPosition.dx);
                    _a = null;
                    _b = null;
                    _playPos = _cur;
                  });
                },
                onHorizontalDragStart: (d) {
                  _dragAnchor = _sampleAt(d.localPosition.dx);
                },
                onHorizontalDragUpdate: (d) {
                  _setSel(_dragAnchor, _sampleAt(d.localPosition.dx));
                },
                child: CustomPaint(
                  size: Size(c.maxWidth, c.maxHeight),
                  painter: _WavePainter(
                    s: _s,
                    mn: _mn,
                    mx: _mx,
                    spp: _spp,
                    start: _start,
                    a: _hasSel ? _a : null,
                    b: _hasSel ? _b : null,
                    cur: _cur,
                    play: _ap.playing ? _playPos : null,
                  ),
                ),
              );
            },
          ),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12),
          child: Row(
            children: [
              IconButton.filledTonal(
                tooltip: 'छोटा करें',
                onPressed: () => _zoom(2),
                icon: const Icon(Icons.zoom_out),
              ),
              Expanded(
                child: Slider(
                  value: _start.clamp(0.0, _maxStart),
                  max: math.max(1.0, _maxStart),
                  onChanged: _maxStart <= 0 ? null : (v) => setState(() => _start = v),
                ),
              ),
              IconButton.filledTonal(
                tooltip: 'बड़ा करें',
                onPressed: () => _zoom(0.5),
                icon: const Icon(Icons.zoom_in),
              ),
              IconButton.filledTonal(
                tooltip: 'पूरा दिखाएँ',
                onPressed: () => setState(_fitAll),
                icon: const Icon(Icons.fit_screen),
              ),
            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12),
          child: Row(
            children: [
              Expanded(
                child: FilledButton.icon(
                  style: FilledButton.styleFrom(backgroundColor: Colors.green.shade700),
                  onPressed: _ap.playing ? _stop : () => _play(selection: false),
                  icon: Icon(_ap.playing ? Icons.pause : Icons.play_arrow),
                  label: Text(_ap.playing ? 'रोकें' : 'यहाँ से चलाएँ'),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: FilledButton.icon(
                  onPressed: _hasSel ? () => _play(selection: true) : null,
                  icon: const Icon(Icons.play_circle_outline),
                  label: const Text('चुना हिस्सा सुनें'),
                ),
              ),
            ],
          ),
        ),
        const Padding(
          padding: EdgeInsets.fromLTRB(12, 8, 12, 0),
          child: Text(
            'छुइए = लाल रेखा रखें  •  उँगली खिसकाइए = हिस्सा चुनें',
            style: TextStyle(fontSize: 13, color: Colors.black54),
          ),
        ),
        Expanded(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(12),
            child: Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                _tool(Icons.content_cut, 'कट', _cut),
                _tool(Icons.copy, 'कॉपी', _copy),
                _tool(Icons.paste, 'पेस्ट', _paste),
                _tool(Icons.delete_outline, 'हटाएँ', _delete),
                _tool(Icons.vertical_split, 'यहाँ से बाँटें', _split),
                _tool(Icons.crop, 'सिर्फ़ चुना रखें', _trim),
                _tool(Icons.volume_off, 'चुना चुप करें', _silence),
                _tool(Icons.auto_fix_high, 'शोर घटाएँ', _busy ? null : _noise),
                _tool(Icons.volume_up, 'आवाज़ कम/ज़्यादा', _gain),
                _tool(Icons.trending_up, 'फ़ेड इन', () => _fade(fadeIn: true)),
                _tool(Icons.trending_down, 'फ़ेड आउट', () => _fade(fadeIn: false)),
                _tool(Icons.equalizer, 'आवाज़ बराबर', _normalizeAll),
              ],
            ),
          ),
        ),
      ],
    );
  }

  int _dragAnchor = 0;

  Widget _tool(IconData icon, String label, VoidCallback? onTap) {
    return OutlinedButton.icon(
      style: OutlinedButton.styleFrom(
        foregroundColor: const Color(0xFF9A3412),
        side: const BorderSide(color: _saffron),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      ),
      onPressed: _busy ? null : onTap,
      icon: Icon(icon),
      label: Text(label, style: const TextStyle(fontSize: 16)),
    );
  }
}

class _WavePainter extends CustomPainter {
  _WavePainter({
    required this.s,
    required this.mn,
    required this.mx,
    required this.spp,
    required this.start,
    required this.a,
    required this.b,
    required this.cur,
    required this.play,
  });

  final Float64List s;
  final Float32List mn;
  final Float32List mx;
  final double spp;
  final double start;
  final int? a;
  final int? b;
  final int cur;
  final int? play;

  double _x(int sample) => (sample - start) / spp;

  @override
  void paint(Canvas canvas, Size size) {
    final mid = size.height / 2;
    final amp = size.height / 2 - 4;
    canvas.drawLine(
      Offset(0, mid),
      Offset(size.width, mid),
      Paint()..color = const Color(0xFFE5E5E5),
    );
    if (a != null && b != null) {
      canvas.drawRect(
        Rect.fromLTRB(_x(a!), 0, _x(b!), size.height),
        Paint()..color = const Color(0x55E8590C),
      );
    }
    final wave = Paint()
      ..color = const Color(0xFF9A3412)
      ..strokeWidth = 1;
    final w = size.width.floor();
    for (var x = 0; x < w; x++) {
      final i0 = (start + x * spp).floor();
      final i1 = math.max(i0 + 1, (start + (x + 1) * spp).ceil());
      if (i0 >= s.length) break;
      var lo = 1.0;
      var hi = -1.0;
      if (spp >= _blk) {
        final b0 = i0 ~/ _blk;
        final b1 = math.min(mn.length - 1, (i1 - 1) ~/ _blk);
        for (var k = b0; k <= b1; k++) {
          if (mn[k] < lo) lo = mn[k];
          if (mx[k] > hi) hi = mx[k];
        }
      } else {
        final end = math.min(i1, s.length);
        for (var i = i0; i < end; i++) {
          final v = s[i];
          if (v < lo) lo = v;
          if (v > hi) hi = v;
        }
      }
      if (hi < lo) continue;
      var y1 = mid - hi * amp;
      var y2 = mid - lo * amp;
      if (y2 - y1 < 1) {
        y1 -= 0.5;
        y2 += 0.5;
      }
      canvas.drawLine(Offset(x + 0.5, y1), Offset(x + 0.5, y2), wave);
    }
    final cx = _x(cur);
    canvas.drawLine(
      Offset(cx, 0),
      Offset(cx, size.height),
      Paint()
        ..color = Colors.red
        ..strokeWidth = 2,
    );
    final p = play;
    if (p != null) {
      final px = _x(p);
      canvas.drawLine(
        Offset(px, 0),
        Offset(px, size.height),
        Paint()
          ..color = Colors.green.shade700
          ..strokeWidth = 2,
      );
    }
  }

  @override
  bool shouldRepaint(_WavePainter old) =>
      old.s != s ||
      old.spp != spp ||
      old.start != start ||
      old.a != a ||
      old.b != b ||
      old.cur != cur ||
      old.play != play;
}
