import 'dart:io';
import 'dart:isolate';

import 'package:flutter/material.dart';

import 'denoise.dart';
import 'wav.dart';

/// पूरी तरह चलने वाला काम: WAV पढ़ो, सफ़ाई करो, नई WAV लिखो (अलग आइसोलेट में)।
Future<void> _cleanFile(({String src, String dst, CleanOptions o}) a) async {
  await Isolate.run(() {
    final w = readWav(a.src);
    final y = cleanAudio(w.samples, w.sampleRate, a.o);
    writeWav(a.dst, y, w.sampleRate);
  });
}

/// फ़ाइल [src] को चुने विकल्पों से साफ़ करके [dst] में लिखता है।
Future<void> cleanWavFile(String src, String dst, CleanOptions o) =>
    _cleanFile((src: src, dst: dst, o: o));

/// शोर हटाने के विकल्प चुनने का डायलॉग। रद्द करने पर null लौटता है।
Future<CleanOptions?> askCleanOptions(
  BuildContext context, {
  CleanOptions initial = const CleanOptions(),
}) {
  var hum = initial.hum;
  var rumble = initial.rumble;
  var hiss = initial.hiss;
  var norm = initial.normalize;
  return showDialog<CleanOptions>(
    context: context,
    builder: (c) => StatefulBuilder(
      builder: (c, setS) => AlertDialog(
        title: const Text('आवाज़ से शोर हटाएँ'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              CheckboxListTile(
                value: hiss,
                onChanged: (v) => setS(() => hiss = v ?? false),
                title: const Text('हिस्स और पंखे का शोर'),
                subtitle: const Text('लगातार आने वाली "शss" या पंखे जैसी आवाज़'),
              ),
              CheckboxListTile(
                value: hum,
                onChanged: (v) => setS(() => hum = v ?? false),
                title: const Text('बिजली की भिनभिनाहट'),
                subtitle: const Text('माइक या स्पीकर की "भुनभुन" (50 Hz)'),
              ),
              CheckboxListTile(
                value: rumble,
                onChanged: (v) => setS(() => rumble = v ?? false),
                title: const Text('हवा और गड़गड़ाहट'),
                subtitle: const Text('फ़ोन पकड़ने, हवा या ज़मीन की नीची आवाज़'),
              ),
              CheckboxListTile(
                value: norm,
                onChanged: (v) => setS(() => norm = v ?? false),
                title: const Text('आवाज़ तेज़ और बराबर करें'),
              ),
              const Padding(
                padding: EdgeInsets.fromLTRB(16, 8, 16, 0),
                child: Text(
                  'ध्यान: यह लगातार चलने वाले शोर के लिए अच्छा है। भीड़ की बातचीत या तालियाँ हटाना मुश्किल है। मूल रिकॉर्डिंग अलग से बची रहती है।',
                  style: TextStyle(fontSize: 13, color: Colors.black54),
                ),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c), child: const Text('रहने दें')),
          FilledButton(
            onPressed: () => Navigator.pop(
              c,
              CleanOptions(hum: hum, rumble: rumble, hiss: hiss, normalize: norm),
            ),
            child: const Text('साफ़ करें'),
          ),
        ],
      ),
    ),
  );
}

/// प्रगति दिखाते हुए सफ़ाई चलाता है। सफल हो तो सच।
Future<bool> runCleanWithProgress(
  BuildContext context,
  String src,
  String dst,
  CleanOptions o,
) async {
  showCleanProgress(context);
  try {
    await cleanWavFile(src, dst, o);
    return true;
  } on Object catch (e) {
    debugPrint('clean error: $e');
    return false;
  } finally {
    if (context.mounted) Navigator.of(context, rootNavigator: true).pop();
  }
}

void showCleanProgress(BuildContext context) {
  showDialog<void>(
    context: context,
    barrierDismissible: false,
    builder: (c) => const AlertDialog(
      content: Row(
        children: [
          CircularProgressIndicator(),
          SizedBox(width: 20),
          Expanded(child: Text('आवाज़ साफ़ हो रही है… कुछ सेकंड रुकिए')),
        ],
      ),
    ),
  );
}

bool isWavPath(String path) => path.toLowerCase().endsWith('.wav');

String cleanedPathFor(String path) {
  final i = path.lastIndexOf('.');
  final base = i > 0 ? path.substring(0, i) : path;
  var out = '$base (साफ़).wav';
  var n = 2;
  while (File(out).existsSync()) {
    out = '$base (साफ़ $n).wav';
    n++;
  }
  return out;
}
