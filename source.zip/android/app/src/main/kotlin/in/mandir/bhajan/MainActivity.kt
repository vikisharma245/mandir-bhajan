package `in`.mandir.bhajan

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
